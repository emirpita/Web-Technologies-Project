const express = require('express')
const app = express()
const port = 8080
const bodyParser = require('body-parser')
const fs = require('fs')
const path=require('path')

var bazaSlika = ['/slike/1.jpg', '/slike/2.jpg', '/slike/3.jpg', '/slike/4.jpg', '/slike/5.jpg', '/slike/6.jpg', '/slike/7.jpg', '/slike/8.jpg']

app.get('/', (req, res) => res.send('WT SPIRALA 3!'))

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/podaciZauzeca', function (req, res) {
  res.sendFile(path.join(__dirname, './', 'zauzeca.json'));
})

app.get('/naredneSlike', function (req, res) {
  
  //parseInt, parseFloat ili Number
  let brojStranice = parseInt(req.query.brojStranice);
  let ukupno = 2;
  let rb1 = brojStranice * 3;
  let rb2 = brojStranice * 3 + 1;
  let rb3 = brojStranice * 3 + 2;
  
  res.send(JSON.stringify({stranica: brojStranice, ukupnoStranica: ukupno, slika1: bazaSlika[rb1], slika2:bazaSlika[rb2], slika3:bazaSlika[rb3] }));
})

app.get('/rezervacija', function (req, res) {
  
  let sala = req.query.sala;
  let periodicnaParametar = req.query.periodicna;
  let periodicna = false;
  if (periodicnaParametar == "true") periodicna = true;
  let pocetak = req.query.pocetak;
  let kraj = req.query.kraj;
  let dan = req.query.dan;
  let mjesec = req.query.mjesec;
  let godina = req.query.godina;
  
  var odgovor = {};
  
  var datumString = dan + "." + mjesec + "." +  godina;
  
  var datum = new Date(godina, mjesec - 1, dan);
  var danSedmica = datum.toString().substring(0, 3);
  
  var pozicijaDana = 0;
  
  if (danSedmica == "Mon") pozicijaDana = 0;
  if (danSedmica == "Tue") pozicijaDana = 1;
  if (danSedmica == "Wed") pozicijaDana = 2;
  if (danSedmica == "Thu") pozicijaDana = 3;
  if (danSedmica == "Fri") pozicijaDana = 4;
  if (danSedmica == "Sat") pozicijaDana = 5;
  if (danSedmica == "Sun") pozicijaDana = 6;
  
  var semestar = "";
  if ( (mjesec - 1) == 9 || (mjesec - 1) == 10 || (mjesec - 1) == 11 || (mjesec - 1) == 0 ) {
	  semestar = "zimski";
	}  
  
  if ( (mjesec - 1) == 1 || (mjesec - 1) == 2 || (mjesec - 1) == 3 || (mjesec - 1) == 4 || (mjesec - 1) == 5 ){
	  semestar = "ljetni";
	}
  
  var jsonFile = fs.readFileSync('zauzeca.json', 'utf-8');
  var jsonData = JSON.parse(jsonFile);
  
  // provjera da li je moguce rezervisati
  // ako je periodicna samo jedno zauzece ako postoji nije moguce
  // ako nije periodicna bitno je da je dan slobodan
  var periodicnaNiz = jsonData.periodicnaZauzeca;
  var vanrednaNiz = jsonData.vanrednaZauzeca;
  var moguceRezervisati = true;
  
  if (periodicna) {	  
	for(i=0; i<periodicnaNiz.length; i++) {
		if ( periodicnaNiz[i].dan === dan && periodicnaNiz[i].semestar === semestar) {
			moguceRezervisati = false;
			break;
		}
	}	 
  } else { //vanredna
	for(i=0; i<vanrednaNiz.length; i++) {
		if (vanrednaNiz[i].datum === datumString) {
			moguceRezervisati = false;
			break;
		}
	}
  }
  
  if (moguceRezervisati && periodicna) {
	  var temp = {};
	  temp.dan = pozicijaDana;
	  temp.semestar = semestar;
	  temp.pocetak = pocetak;
	  temp.kraj = kraj;
	  temp.naziv = "test naziv";
	  temp.predavac = "test predavac";
	  periodicnaNiz.push(temp);
  }
  
  if (moguceRezervisati && !periodicna) {
	  var temp = {};
	  temp.datum = datumString;
	  temp.pocetak = pocetak;
	  temp.kraj = kraj;
	  temp.naziv = "test naziv";
	  temp.predavac = "test predavac";
	  vanrednaNiz.push(temp);
  }
  
  var noviJson = {};
  noviJson.periodicnaZauzeca = periodicnaNiz;
  noviJson.vanrednaZauzeca = vanrednaNiz;
  
  if(moguceRezervisati) fs.writeFileSync('zauzeca.json', JSON.stringify(noviJson));
  
  if(moguceRezervisati) { 
	odgovor.greska = "OK";
	odgovor.periodicnaZauzeca = periodicnaNiz;
	odgovor.vanrednaZauzeca = vanrednaNiz;
  };
  if(!moguceRezervisati) {
	  odgovor.greska = "Nije moguce rezervisati salu " + sala + " za navedeni datum " + dan + "/" + mjesec + "/" + godina + " i termin od " + pocetak + " do " + kraj + "!";
  }

  res.send(JSON.stringify(odgovor));
})

app.use(express.static('public'))

app.listen(port, () => console.log(`Aplikacija pokrenuta na portu: ${port}!`))