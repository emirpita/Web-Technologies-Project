var datumTrenutni = new Date();
var mjesecTrenutni = datumTrenutni.getMonth();

Kalendar.iscrtajKalendar(document.getElementById("kalendar"), mjesecTrenutni);

document.getElementById("btnNaredni").addEventListener("click", Kalendar.aktivniMjesecNaprijed);
document.getElementById("btnPrethodni").addEventListener("click", Kalendar.aktivniMjesecNazad);

var zauzecaJson = Pozivi.ucitajPodatkeAjax();
var periodicnaZauzecaData = zauzecaJson.periodicnaZauzeca;
var vanrednaZauzecaData = zauzecaJson.vanrednaZauzeca;

Kalendar.ucitajPodatke(periodicnaZauzecaData, vanrednaZauzecaData);
Kalendar.podesiAktivniMjesec(mjesecTrenutni);
Kalendar.inicijalizirajKalendar();

function rezervisi() {
	var cssKlasa = this.getAttribute("class");
	
	var danDjeca = this.children;
	var dan = danDjeca[0].innerText;
	
	var pozicijaDana = false;
	var slobodanDan = false;
	
	// da li listner da poziciji koja je dan u kalendaru
	if(cssKlasa=="dan") {
		pozicijaDana = true;
		//da li je dan slobodan ili nije, tj da li moguca rezervacija
		var danDjeca = this.children;
		if(danDjeca[1].getAttribute("class") == "statusDan slobodna" ) {
			slobodanDan = true;
		}	
	}
	
	if (pozicijaDana && slobodanDan) {
		
		if (confirm('Da li zelite da rezervisete ovaj termin?')) {
			
			var sala = document.getElementById("frmSala").value;
			var periodicna = document.getElementById("frmPeriodicna").checked;
			var pocetak = document.getElementById("frmPocetak").value;
			var kraj = document.getElementById("frmKraj").value;
			
			//var datumTrenutni = new Date();
			var godina = datumTrenutni.getFullYear();
			
			var mjesecNazivNizObj = document.getElementsByClassName("mjesecNaslov");
			var mjesecNazivObj = mjesecNazivNizObj[0];
			var mjesecNazivObjDjeca = mjesecNazivObj.children;
			var mjesecNaziv = mjesecNazivObjDjeca[0].innerText;
			
			var mjesec = Kalendar.redniBrojMjeseca(mjesecNaziv);
			
			if (pocetak == "" || kraj == "") {
				alert("Nedostaju podaci");
			} else {
				// odgovor json
				var jsonOdgovor = Pozivi.rezervacija(dan, mjesec, godina, sala, periodicna, pocetak, kraj);
				if (jsonOdgovor.greska == "OK") {
					var periodicnaZauzecaData = jsonOdgovor.periodicnaZauzeca;
					var vanrednaZauzecaData = jsonOdgovor.vanrednaZauzeca;
					Kalendar.ucitajPodatke(periodicnaZauzecaData, vanrednaZauzecaData);
					Kalendar.inicijalizirajKalendar();				
				} else {
					alert(jsonOdgovor.greska);
					var zauzecaJson = Pozivi.ucitajPodatkeAjax();
					var periodicnaZauzecaData = zauzecaJson.periodicnaZauzeca;
					var vanrednaZauzecaData = zauzecaJson.vanrednaZauzeca;
					Kalendar.ucitajPodatke(periodicnaZauzecaData, vanrednaZauzecaData);					
					Kalendar.inicijalizirajKalendar();	
				}
			}
			
		} 
		
	}
	
}

var elementiDani = document.getElementsByClassName("dan");
for (var i = 0; i < elementiDani.length; i++) {
    elementiDani[i].addEventListener('click', rezervisi, false);
}