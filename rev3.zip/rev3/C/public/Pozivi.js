let Pozivi = ( function () {
	
	function ucitajPodatkeAjaxImp() {
		var xhttp = new XMLHttpRequest();
		xhttp.open("GET", "/podaciZauzeca", false);
		xhttp.send();
		var zauzecaJson = JSON.parse(xhttp.responseText);
		return zauzecaJson;
	}
	
	function ucitajNaredneSlikeImp(stranica) {
		var urlZaPoziv = "/naredneSlike?brojStranice=" + stranica;
		var xhttp = new XMLHttpRequest();
		xhttp.open("GET", urlZaPoziv, false);
		xhttp.send();
		var slikeJson = JSON.parse(xhttp.responseText);
		return slikeJson;
	}
	
	function rezervacijaImp(dan, mjesec, godina, sala, periodicna, pocetak, kraj) {
		
		//var urlZaPoziv ="";
		var urlZaPoziv = "/rezervacija?sala=" + sala + "&periodicna=" + periodicna + "&pocetak=" + pocetak + "&kraj=" + kraj + "&dan=" + dan + "&mjesec=" + mjesec + "&godina=" + godina ;
		var xhttp = new XMLHttpRequest();
		xhttp.open("GET", urlZaPoziv, false);
		xhttp.send();
		var odgovorJson = JSON.parse(xhttp.responseText);
		return odgovorJson;
		
	}
	
	return {
		ucitajPodatkeAjax: ucitajPodatkeAjaxImp,	
		ucitajNaredneSlike: ucitajNaredneSlikeImp,
		rezervacija: rezervacijaImp
	}
	
} () );