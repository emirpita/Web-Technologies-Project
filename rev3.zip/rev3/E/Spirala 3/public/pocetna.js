pomocnaFunkcija();

function pomocnaFunkcija(){
    Pozivi.ucitajSlike(slike);
} 