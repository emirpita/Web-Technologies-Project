var slike = 0;

let Pozivi = (function(){
    var ajax = new XMLHttpRequest();
    var ajaxDva = new XMLHttpRequest();
    var ajaxTri = new XMLHttpRequest();
    var ajaxCetiri = new XMLHttpRequest();
    var zauzeta = null;
    var statickeSlike = new Array(10). fill("");
    var indexSlike = 0;

    function ucitajJSONPodatke(){
        ajax.onreadystatechange = function(){
            if(ajax.readyState == 4 && ajax.status == 200){
                var niz = JSON.parse(ajax.response); 
                Kalendar.ucitajPodatke(niz.periodicna, niz.vanredna);
                Kalendar.iscrtajKalendar(document.getElementById('calendar'), mjesec);
            } 

            if(ajax.readyState == 4 && ajax.status == 404) {
                console.log("greska");
            }
        }
        
        ajax.open("GET", "http://localhost:8080/rezervacija", true);
        ajax.setRequestHeader('Content-Type', 'application/json');
        ajax.send();
    }  

    function provjeriZauzetost(datumDana){
        var pocetak = document.getElementById("poc").value;
        var kraj = document.getElementById("kraj").value;

        if(!pocetak || !kraj || pocetak > kraj || pocetak == kraj){
            alert("Unesite pocetak i kraj korektno (Neispravan format vremena)!");
        } else {
                //datum mjeseca koji odabiremo
            var datum = datumDana;
            var i = Kalendar.vratiMjesec() + 1;
            var period = Kalendar.mjesecSemestra(i-1);

            if(i < 10) datum += "0" + i + ".2019"
            else datum += i + ".2019";


            var checkbox = document.getElementById("check").checked; 
            var selektorSala = document.getElementById("sale");
            var sala = selektorSala.options[selektorSala.selectedIndex].value; 
            var predavac = "xx";
            var kolonaSelektovanogDana = Kalendar.vratiPocetnuKolonu();
            var brojDana = parseInt(datumDana.substring(0, 2), 10) - 1;

            kolonaSelektovanogDana += brojDana;

                while(kolonaSelektovanogDana >= 7){
                    kolonaSelektovanogDana -= 7;
                }

            ajaxDva.onreadystatechange = function(){ 
                if(ajaxDva.readyState == 4 && ajaxDva.status == 200){  
                    zauzeta = ajaxDva.response;
                    console.log(zauzeta);

                    rezervisiDan(datumDana);
                } 

                if(ajaxDva.readyState == 4 && ajaxDva.status == 404) {
                    alert("Nije moguće rezervisati salu " + sala + " za navedeni datum " + datum + " i terminu od " + pocetak +" do " + kraj +"!");
                }
            }

            ajaxDva.open("GET", "http://localhost:8080/datum/" + datum + "/pocetak/" + pocetak + "/kraj/" + kraj + "/naziv/" + sala + "/predavac/" + predavac + "/checkbox/" + checkbox + "/period/" + period + "/kolona/" + kolonaSelektovanogDana, true);
            ajaxDva.send();
        }
    }

    function rezervisiDan(datumDana){
        var pocetak = document.getElementById("poc").value;
        var kraj = document.getElementById("kraj").value;

        if(!pocetak || !kraj || pocetak > kraj || pocetak == kraj){
            alert("Unesite pocetak i kraj korektno (Neispravan format vremena)!");
        } else {
                //datum mjeseca koji odabiremo
            var datum = datumDana;
            var i = Kalendar.vratiMjesec() + 1;
            var period = Kalendar.mjesecSemestra(i-1);

                if(i < 10) datum += "0" + i + ".2019"
                else datum += i + ".2019";


            var checkbox = document.getElementById("check").checked; 
            var selektorSala = document.getElementById("sale");
            var sala = selektorSala.options[selektorSala.selectedIndex].value;

            if(zauzeta == "true" || (checkbox == true && (i == 7 || i == 8 || i == 9))){
                alert("Nije moguće rezervisati salu " + sala + " za navedeni datum " + datum + " i terminu od " + pocetak +" do " + kraj +"!");
            } 
            else if(confirm("Da li zelite rezervisati ovaj termin?")){
                //salji ajax zahtjev za termin
                var predavac = "xx";
                var kolonaSelektovanogDana = Kalendar.vratiPocetnuKolonu();
                var brojDana = parseInt(datumDana.substring(0, 2), 10) - 1;

                kolonaSelektovanogDana += brojDana;

                while(kolonaSelektovanogDana >= 7){
                    kolonaSelektovanogDana = kolonaSelektovanogDana - 7;
                }

                ajaxCetiri.onreadystatechange = function(){
                    if(ajaxCetiri.readyState == 4 && ajaxCetiri.status == 200){ 
                        ucitajJSONPodatke();
                    } 
        
                    if(ajaxCetiri.readyState == 4 && ajaxCetiri.status == 404) {
                        alert("Nije moguće rezervisati salu " + sala + " za navedeni datum " + datum + " i terminu od " + pocetak +" do " + kraj +"!");
                    }
                }
            
                ajaxCetiri.open("POST", "http://localhost:8080/datum/" + datum + "/pocetak/" + pocetak + "/kraj/" + kraj + "/naziv/" + sala + "/predavac/" + predavac + "/checkbox/" + checkbox + "/period/" + period + "/kolona/" + kolonaSelektovanogDana, true);
                ajaxCetiri.send();

            }
        }
    }

    function ucitajSlike(slike){
        if(document.getElementById("back").disabled && slike != 0)
            document.getElementById("back").disabled = false;

        ajaxTri.onreadystatechange = function(){
            if(ajaxTri.readyState == 4 && ajaxTri.status == 200){
                var privremenaSlike = ajaxTri.response.split(" ");
                var duzine = 3;                
                if(privremenaSlike.length < 3) document.getElementById("next").disabled = true;

                if(slike != 0) 
                    duzine = duzine + 3*slike; 

                    for(var i = indexSlike, j = 0; i < duzine, j < 3; i++, j++){
                        statickeSlike[i] = privremenaSlike[j];
                    }

                indexSlike = duzine;

                if(privremenaSlike[0] != "")
                    document.getElementById("prva").src = privremenaSlike[0];
                else 
                    document.getElementById("prva").src = "";

                if(privremenaSlike[1] != "")
                    document.getElementById("druga").src = privremenaSlike[1];
                else 
                    document.getElementById("druga").src = "";

                if(privremenaSlike.length == 3 && privremenaSlike[2] != "")
                    document.getElementById("treca").src = privremenaSlike[2];
                else 
                    document.getElementById("treca").src = "";

            } 

            if(ajaxTri.readyState == 4 && ajaxTri.status == 404) {
                console.log("greska");
            }
        }
      
        ajaxTri.open("GET", "http://localhost:8080/slike/" + slike, true);
        ajaxTri.send();
    }

    function vratiSlike(slike){ 

        document.getElementById("next").disabled = false;
        if(slike == 0) document.getElementById("back").disabled = true;
        tmp = indexSlike - 3;
        
        document.getElementById("prva").src = statickeSlike[tmp - 3];
        document.getElementById("druga").src = statickeSlike[tmp - 2];
        document.getElementById("treca").src = statickeSlike[tmp - 1];

        indexSlike = indexSlike - 3; //vratimo index shodno vracanju na prethodni blok slika
    }

    return{
        ucitajJSONPodatke: ucitajJSONPodatke,
        rezervisiDan: rezervisiDan, 
        ucitajSlike: ucitajSlike,
        vratiSlike: vratiSlike,
        provjeriZauzetost: provjeriZauzetost
    }
}());
