let assert = chai.assert;
describe('Kalendar', function() {
  describe('iscrtajKalendar()', function() {
    it('Trebao bi imati 31 dan', function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"),11);
      let kalendar = document.getElementById("kalendar");
      let dani = 0;
      for(var k = 0; k < 6; k++) {
        var sedmica = kalendar.getElementsByClassName("sedmica").item(k);
        var j = k*7;
        var brojac = 7;
        var i_dat = 0;
        while(brojac != 0) {
          var dan = sedmica.getElementsByClassName("dat").item(i_dat);
          if(dan.textContent != '') {
              dani++;      
          }
          brojac--;
          i_dat++;
          j++;
        }
      }
      assert.equal(dani, 31,"Trebao bi imati 31 dan");
   });
    it('Trebao bi imati 30 dana', function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"),8);
      let kalendar = document.getElementById("kalendar");
      let dani = 0;
      for(var k = 0; k < 6; k++) {
        var sedmica = kalendar.getElementsByClassName("sedmica").item(k);
        var j = k*7;
        var brojac = 7;
        var i_dat = 0;
        while(brojac != 0) {
          var dan = sedmica.getElementsByClassName("dat").item(i_dat);
          if(dan.textContent != '') {
            dani++;      
          }
          brojac--;
          i_dat++;
          j++;
        }
      }
      assert.equal(dani, 30,"Trebao bi imati 30 dana");
    });
    it('Prvi dan bi trebao biti petak', function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"),10);
      let kalendar = document.getElementById("kalendar");
      let prvi = 0;
      for(var k = 0; k < 1; k++) {
        var sedmica = kalendar.getElementsByClassName("sedmica").item(k);
        var j = k*7;
        var brojac = 7;
        var i_dat = 0;
        while(brojac != 0) {
          var dan = sedmica.getElementsByClassName("dat").item(i_dat);
          if(dan.textContent != '') {
              prvi = i_dat; 
              break;     
          }
          brojac--;
          i_dat++;
          j++;
        }
      }
      assert.equal(prvi, 4,"Prvi dan bi trebao biti petak");
    });
    it('Trideseti dan u mjesecu bi trebala biti subota', function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"),10);
      let kalendar = document.getElementById("kalendar");
      let trideseti = 0;
      let brojacDana = 0;
      for(var k = 0; k < 6; k++) {
        var sedmica = kalendar.getElementsByClassName("sedmica").item(k);
        var j = k*7;
        var brojac = 7;
        var i_dat = 0;
        while(brojac != 0) {
          var dan = sedmica.getElementsByClassName("dat").item(i_dat);
          if(dan.textContent != '') {
            brojacDana++; 
            if(brojacDana == 30) {
              trideseti = i_dat;
              break;
            }
                 
          }
          brojac--;
          i_dat++;
          j++;
        }
      }
      assert.equal(trideseti, 5,"Trideseti dan u mjesecu bi trebala biti subota");
    });
    it('Januar bi trebao imati 31 dan i utroark bi trebao biti prvi dan u mjesecu', function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"),0);
      let kalendar = document.getElementById("kalendar");
      let prviUtorak = 0;
      let brojacDana = 0;
      for(var k = 0; k < 5; k++) {
        var sedmica = kalendar.getElementsByClassName("sedmica").item(k);
        var j = k*7;
        var brojac = 7;
        var i_dat = 0;
        while(brojac != 0) {
          var dan = sedmica.getElementsByClassName("dat").item(i_dat);
          if(dan.textContent != '') {
            brojacDana++; 
            if(brojacDana == 1) {
              prviUtorak = i_dat;
            }      
          }
          brojac--;
          i_dat++;
          j++;
        }
      }
      assert.equal(brojacDana, 31,"Treba imati 31 dan");
      assert.equal(prviUtorak, 1,"Utorak treba biti prvi dan");
    });
    it('Prvi mjesec bi trebao biti januar', function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"),0);
      let mjesec = document.getElementById("mjesec").textContent;
      assert.equal(mjesec, "Januar","Prvi mjesec bi trebao biti januar");
    });
    it('Februar bi trebao imati 28 dana', function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"),1);
      let kalendar = document.getElementById("kalendar");
      let dani = 0;
      for(var k = 0; k < 5; k++) {
        var sedmica = kalendar.getElementsByClassName("sedmica").item(k);
        var j = k*7;
        var brojac = 7;
        var i_dat = 0;
        while(brojac != 0) {
          var dan = sedmica.getElementsByClassName("dat").item(i_dat);
          if(dan.textContent != '') {
            dani++;      
          }
          brojac--;
          i_dat++;
          j++;
        }
      }
      assert.equal(dani, 28,"Februar bi trebao imati 28 dana");
    });
  });
  describe('obojiZauzeca()', function() {
    it('Ne bi trebao imati zauzeca', function() {
      Kalendar.obojiZauzeca(document.getElementById("glavniDIo"),10,'MA','13:30','15:00');
      let zauzeta = document.getElementsByClassName("zauzeta");
      assert.equal(zauzeta.length, 0,"Trebao bi imati 0 zauzetih");
    });
    
    it('Ne bi trebao imati zauzeca u ljetnom', function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"),10);
      var periodicno1 = {
        dan: 0,
        semestar: "ljetni",
        pocetak: "13:30",
        kraj: "15:00",
        naziv: "MA",
        predavac: "NN"
      }
      var periodicno2 = {
        dan: 0,
        semestar: "ljetni",
        pocetak: "12:30",
        kraj: "16:00",
        naziv: "VA",
        predavac: "ZJ"
      }
      var periodicna = [periodicno1,periodicno2];
      var vanredno = [];
      Kalendar.ucitajPodatke(periodicna,vanredno);
      Kalendar.obojiZauzeca(document.getElementById("glavniDIo"),10,'MA','13:30','15:00');
      let zauzeta = document.getElementsByClassName("zauzeta");
      assert.equal(zauzeta.length, 0,"Trebao bi imati 0 zauzetih");
    });
    it('Ne bi trebao imati zauzeca u drugom mjesecu', function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"),10);
      var periodicno1 = {
        dan: 0,
        semestar: "ljetni",
        pocetak: "13:30",
        kraj: "15:00",
        naziv: "MA",
        predavac: "NN"
      }
      var periodicno2 = {
        dan: 0,
        semestar: "ljetni",
        pocetak: "12:30",
        kraj: "16:00",
        naziv: "VA",
        predavac: "ZJ"
      }
      var periodicna = [periodicno1,periodicno2];
      var vanredno = [];
      Kalendar.ucitajPodatke(periodicna,vanredno);
      Kalendar.obojiZauzeca(document.getElementById("glavniDIo"),11,'MA','13:30','15:00');
      let zauzeta = document.getElementsByClassName("zauzeta");
      assert.equal(zauzeta.length, 0,"Trebao bi imati 0 zauzetih");
    });
    it('Ne bi trebao imati vanrednih zauzeca u drugom mjesecu', function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"),10);
      var vanredno1 = {
        datum: "30.12.2019",  
        pocetak: "12:00",
        kraj: "15:00",
        naziv: "1-01",
        predavac: "ZJ"
      }
      var periodicna = [];
      var vanredno = [vanredno1];
      Kalendar.ucitajPodatke(periodicna,vanredno);
      Kalendar.obojiZauzeca(document.getElementById("glavniDIo"),11,'MA','13:30','15:00');
      let zauzeta = document.getElementsByClassName("zauzeta");
      assert.equal(zauzeta.length, 0,"Trebao bi imati 0 zauzetih");
    });
    it('Ne bi trebao imati vanrednih zauzeca u drugom semestru', function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"),10);
      var vanredno1 = {
        datum: "30.3.2019",  
        pocetak: "12:00",
        kraj: "15:00",
        naziv: "1-01",
        predavac: "ZJ"
      }
      var periodicna = [];
      var vanredno = [vanredno1];
      Kalendar.ucitajPodatke(periodicna,vanredno);
      Kalendar.obojiZauzeca(document.getElementById("glavniDIo"),11,'MA','13:30','15:00');
      let zauzeta = document.getElementsByClassName("zauzeta");
      assert.equal(zauzeta.length, 0,"Trebao bi imati 0 zauzetih");
    });
    it("Pozivanje obojiZauzeca gdje u zauzećima postoje duple vrijednosti za zauzeće istog termina,očekivano je da se dan oboji bez obzira što postoje duple vrijednosti", function() {
      let periodicna1= [];
      let vanredna1 = [
        {   
          datum: "15.11.2019",
          pocetak: "10:00",
          kraj: "12:00",
          naziv: "0-01",
          predavac: "Predavac"
        },
        {
          datum: "15.11.2019",
          pocetak: "10:00",
          kraj: "12:00",
          naziv: "0-01",
          predavac: "Predavac"
        }];
      Kalendar.ucitajPodatke(periodicna1, vanredna1);
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
      Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00",);   
      let dani = document.getElementsByClassName("dat zauzeta");
      let brojac = 0;
      for (let i = 0; i < dani.length; i++) {
        if (dani[i].className.search("zauzeta") != -1) {
            brojac++;
          }
        }
        assert.equal(brojac, 1, "Treba se obojiti jedan dan");
      });
      it('Trebao imati jedno zauzece', function() {
        var periodicno1 = {
          dan: 0,
          semestar: "zimski",
          pocetak: "13:30",
          kraj: "15:00",
          naziv: "MA",
          predavac: "NN"
        }
        var periodicno2 = {
          dan: 0,
          semestar: "zimski",
          pocetak: "13:30",
          kraj: "15:00",
          naziv: "VA",
          predavac: "ZJ"
        }
        var periodicna = [periodicno1,periodicno2];
        var vanredno = [];
        Kalendar.ucitajPodatke(periodicna,vanredno);
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"),10);
        Kalendar.obojiZauzeca(document.getElementById("glavniDIo"),10,'MA','13:30','15:00');
        Kalendar.obojiZauzeca(document.getElementById("glavniDIo"),10,'MA','13:30','15:00');
        let kalendar = document.getElementById("kalendar");
        let zauzeti = 0;
        for(var k = 0; k < 5; k++) {
          var sedmica = kalendar.getElementsByClassName("sedmica").item(k);
          var j = k*7;
          var brojac = 7;
          var i_dat = 0;
          while(brojac != 0) {
            var dan = sedmica.getElementsByClassName("dat").item(i_dat);
            if(dan.textContent != '' && dan.classList.contains("zauzeta")) {
                zauzeti++;
            }
            brojac--;
            i_dat++;
            j++;
          }
        }
        assert.equal(zauzeti, 1 ,"Trebao bi imati 1 zauzetih");
      });
    }); 
  });

