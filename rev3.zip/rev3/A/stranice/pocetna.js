//function pocetna() {
    //alert("usaooo");
    var sadrzaj = document.getElementById("slike");
    var slike = [
        {"url": "https://i.pinimg.com/564x/0e/8a/5a/0e8a5a1e632d996b7742fc5fd99ef723.jpg"},
        {"url": "https://i.pinimg.com/564x/7a/10/d5/7a10d5484a87a51f209d4c96a1b7f5cc.jpg"},
        {"url": "https://i.pinimg.com/564x/19/bd/18/19bd18485f7f36660368b3f26bfab1ff.jpg"},
        {"url": "https://i.pinimg.com/564x/73/be/b5/73beb57bacf0d48a7b9fc900752271d2.jpg"},
        {"url": "https://i.pinimg.com/564x/ac/b6/20/acb620561053abe75ac764be287b97c2.jpg"},
        {"url": "https://i.pinimg.com/564x/6b/d7/70/6bd770cc45a9098ff3e07a1825f4c0bc.jpg"},
        {"url": "https://i.pinimg.com/564x/2d/21/0a/2d210a254ec1887a741e196d1bc82e7a.jpg"},
        {"url": "https://i.pinimg.com/564x/23/e5/bf/23e5bfee30cda999fbee2717a7818378.jpg"},
        {"url": "https://i.pinimg.com/564x/9f/74/0d/9f740d89f9713eec25746d62fe7daac2.jpg"},
        {"url": "https://i.pinimg.com/564x/fe/0f/e1/fe0fe176dd2558f70cf7bd32eb264560.jpg"}
    ];
    //spasiSlike(slike);
    Pozivi.prikaziPocetnu(sadrzaj);
//}


