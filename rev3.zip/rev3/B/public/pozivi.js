let Pozivi = (function(){

  var prvaSlika;
  var drugaSlika;
  var trecaSlika;

  var slikeDOM=document.getElementById('slike');

 var ucitanaZadnjaSlika=false; 
  
var obj=[];

var porukaORezervaciji=false;

var slike=[];




function loadJSONPodaci(callback){
   
      var ajax = new XMLHttpRequest();
        ajax.overrideMimeType("application/json");
        ajax.open('GET', 'zauzeca.json', true);
        ajax.onreadystatechange = function () {
          if (ajax.readyState == 4 && ajax.status == "200") {
           
            callback(ajax.responseText);
            }
        };
        
        ajax.send(); 

}

function ucitajPodatkeJSONImpl() {

  loadJSONPodaci(function(response) {
     obj = JSON.parse(response);
     Kalendar.ucitajPodatke(obj.periodicna,obj.vanredna);
     oboji();
     console.log(obj);
     if(porukaORezervaciji)
      alert("Rezervisano!");
  });
 }




function loadJSONZauzece(zauzece,callback) {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", 'zauzeca.json', true);
    xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhr.onreadystatechange = function () {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                   object = JSON.parse(xhr.responseText);
                callback(object);
            } else {

            }
        }
    };

   
    xhr.send(JSON.stringify(zauzece));
}

function upisiZauzeceJSONImpl(zauzece){
         loadJSONZauzece(zauzece,function(response){
             if(response.periodicna || response.vanredna)
              {
                porukaORezervaciji=true;
                ucitajPodatkeJSONImpl();
                //alert("Rezervisano!");
             }
              else if(response="greska")
              {
                var podaci=podaciKlika();
                var poruka= "Nije moguće rezervisati salu "+podaci.naziv +" za navedeni datum "+podaci.datum+" i termin od "
                +podaci.pocetak +" do "+ podaci.kraj +"!";
                alert (poruka);               
              }

    
         }) 
    };

  
    function ucitajSlikeAjax(p,callback) {
      var poziv={poziv:p};
      var xhr = new XMLHttpRequest();
     
      xhr.open("POST", '/slike', true);
      xhr.overrideMimeType("application/json");
      xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
      xhr.onreadystatechange = function () {
          if (xhr.readyState === XMLHttpRequest.DONE) {
              if (xhr.status === 200) {
                  
                  object = JSON.parse(xhr.responseText);
                  callback(object);
              } else {
  
              }
          }
      };
      xhr.send(JSON.stringify(poziv));
     
  }
  
  function ucitajSlikeImpl(poziv){
          


           ucitajSlikeAjax(poziv,function(response){
       
            console.log("Ajax odgovor: ")
             console.log(response);

             if(poziv=="onload")
             {
        
            for(var i=0; i<3; i++)
              {  var img = document.createElement('img'); 
                  slikeDOM.appendChild(img);
                if(i==0)
                  img.id="prvaSlika";
                else if(i==1)
                  img.id="drugaSlika";
                else
                  img.id="trecaSlika";

              }

               prvaSlika=$('#prvaSlika');
               drugaSlika=$('#drugaSlika');
               trecaSlika=$('#trecaSlika');
             }
          

             if(response.brojSlika==0)
             {
               ucitanaZadnjaSlika=true; 
             }
             
            
           if(response.slika1 && response.slika2 &&  response.slika3)
           { 
             prvaSlika.attr('src', response.slika1); slike.push(response.slika1);
            drugaSlika.attr('src', response.slika2); slike.push(response.slika2);
            trecaSlika.attr('src', response.slika3); slike.push(response.slika3);
            if(response.brojSlika==0)
            {
                $('#sljedeci').prop('disabled', true);
           
                JedanIliDva=0;
           
                $("#sljedeci").css("background-color", "red");

            
            }


           }
           else if(response.slika1 && response.slika2)
           {
             prvaSlika.attr('src', response.slika1); slike.push(response.slika1);
             drugaSlika.attr('src',response.slika2); slike.push(response.slika2);
             trecaSlika.remove();
            
            
             $('#sljedeci').prop('disabled', true);

             $("#sljedeci").css("background-color", "red");
           }
           else{
            prvaSlika.attr('src', response.slika1);  slike.push(response.slika1);
            drugaSlika.remove();
            trecaSlika.remove();
           
            $('#sljedeci').prop('disabled', true);

            $("#sljedeci").css("background-color", "red");
          }
           

           }) 
      };
  
    
  function vratiSlikeImpl()
  {
    return slike;
  }

  function vratiZadnjaSlikaImpl()
  {
    return ucitanaZadnjaSlika;
  }

 

return {

ucitajPodatkeJSON: ucitajPodatkeJSONImpl,
upisiZauzeceJSON: upisiZauzeceJSONImpl,
ucitajSlike:ucitajSlikeImpl,



vratiSlike:vratiSlikeImpl,
vratiZadnjaSlika:vratiZadnjaSlikaImpl

}
}());

