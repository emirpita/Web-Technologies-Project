var express = require('express');
var app = express();
var path = require('path');
var bodyParser = require('body-parser');
const fs = require('fs');
const session = require("express-session");




app.use(bodyParser.urlencoded({extended: true}))
app.use(bodyParser.json())
app.use(express.static('public'));
app.use('/slike', express.static(__dirname + '/slike'));

app.use(session({
  secret: 'neka tajna sifra',
  resave: true,
  saveUninitialized: true
}));


app.get('/', function(req, res) {
    res.sendFile((__dirname + '/public/pocetna.html')); 
});



app.get('/zauzeca.json', (req, res) => {   
  res.sendFile('zauzeca.json', { root: __dirname });
});




app.post('/zauzeca.json', function (req, res) {
    
   var zauzece=req.body;
  
   
   let podaci = fs.readFileSync((__dirname, 'zauzeca.json'));
   let zauzeca = JSON.parse(podaci);

   provjera1=(provjeriSaluPeriodicna(zauzece,zauzeca.periodicna));
   provjera2=(provjeriSaluVanredna(zauzece,zauzeca.vanredna));
   
   if(provjera1==false && provjera2==false)
   {
     
     if(zauzece.dan)
          zauzeca.periodicna.push(zauzece);
     else 
        zauzeca.vanredna.push(zauzece); 
      
       fs.writeFile(path.join(__dirname, 'zauzeca.json'), JSON.stringify(zauzeca,null,'\t'), (err) => {
          if (err) throw err;
          console.log('Zauzece upisano!');
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify(zauzeca));
        })
          
   }
   else{
   var poruka="greska"
   res.setHeader('Content-Type', 'application/json');
   res.end(JSON.stringify(poruka));
  }


});


    
/* ne treba zbog linije 14
    app.get('/slike/:filename', (req, res) => {  
      
    var slika = req.params.filename;

    slike=[];
     
    fs.readdir(__dirname+'/slike', function (err, files) {
     
        if (err) throw err;
        files.forEach(function (file) {
            slike.push(file);
           });

           
           for(var i=0; i<slike.length; i++)
           {
             if(slika==slike[i]){
               var path=__dirname+'/slike/'+slika;
               res.sendFile(path);
             }
           }
       });
      });
   
 */     
 
      
   
    app.post('/slike', function(req, res){
      
     
      
       var slike=[];
       var poziv=req.body;
     

     
        fs.readdir(__dirname+'/slike', function (err, files) {

         
             if (err) throw err;
          files.forEach(function (file) {
              slike.push(file);
             });

            if(req.session.brojac!=null) {
              
               
            if(slike[req.session.brojac+3] && slike[req.session.brojac+2] && slike[req.session.brojac+1])
                 { req.session.brojac+=3; req.session.broj=3; }
            
            else if(slike[req.session.brojac+2] && slike[req.session.brojac+1])  
                 {req.session.brojac+=2; req.session.broj=2;} 
            
            else if(slike[req.session.brojac+1])
                 {req.session.brojac+=1; req.session.broj=1;}

            
             }
             else {
                 req.session.brojac=2;
                 req.session.broj=3;
                
                 
             }

             if(poziv.poziv=="onload") 
             {
              req.session.brojac=2;
              req.session.broj=3;
             
              } 
           
            
              var brojSlika=req.session.broj;
              var brojac=req.session.brojac;
              var s='/slike/'

            
              var obj;
           

             if(brojSlika==3)
             {
              obj={slika1:s+slike[brojac-2], slika2:s+slike[brojac-1], slika3:s+slike[brojac], brojSlika:slike.length-brojac-1};
             }
             else if(brojSlika==2)
             {
              obj={slika1:s+slike[brojac-1],slika2:s+slike[brojac],brojSlika:slike.length-brojac-1};
             }
             else{
              obj={slika1:s+slike[brojac],brojSlika:slike.length-brojac-1};
             }
      

         
         res.writeHead(200);
         res.write(JSON.stringify(obj));
         res.end();
              
       
    });

           
    })
 

  app.listen(8080, () => {
    console.log("Server pokrenut, osluškivanje na portu 8080!");
});
 


function provjeriSaluPeriodicna(zauzece,zauzeca)
{
  if(zauzece.dan)
  {
  for(var i=0; i<zauzeca.length; i++)
  {
    var z=zauzeca[i];
    if(zauzece.dan==z.dan && zauzece.semestar==z.semestar &&zauzece.naziv==z.naziv)
    {
       var bool =vratiPresjek(zauzece.pocetak, zauzece.kraj, z.pocetak, z.kraj);
      
       return bool;

    }
 
  }
  return false;
 }
 else if(zauzece.datum)
 {
    var dan=dajDan(zauzece.datum);
    var mjesec=dajMjesec(zauzece.datum);
    var semestar=Semestar(mjesec);

    for(var i=0; i<zauzeca.length; i++)
    {
      var z=zauzeca[i];
      

      if(dan==z.dan && semestar==z.semestar &&zauzece.naziv==z.naziv)
      {
         var bool =vratiPresjek(zauzece.pocetak, zauzece.kraj, z.pocetak, z.kraj);
        
         return bool;
  
      }
   
    }
    return false;
    
 }
}

function provjeriSaluVanredna(zauzece,zauzeca)
{
  if(zauzece.dan)
  { 

  for(var i=0; i<zauzeca.length; i++)
  {
    var z=zauzeca[i];
    var dan=dajDan(z.datum);
    var mjesec=dajMjesec(z.datum);
    var semestar=Semestar(mjesec);
    if(zauzece.dan==dan && zauzece.semestar==semestar &&zauzece.naziv==z.naziv)
    {
       var bool =vratiPresjek(zauzece.pocetak, zauzece.kraj, z.pocetak, z.kraj);
      
       return bool;

    }
 
  }
  return false;
 }
 else if(zauzece.datum)
 {
    
    for(var i=0; i<zauzeca.length; i++)
    {
      var z=zauzeca[i];
      

      if(zauzece.datum==z.datum  &&zauzece.naziv==z.naziv)
      {
         var bool =vratiPresjek(zauzece.pocetak, zauzece.kraj, z.pocetak, z.kraj);
        
         return bool;
  
      }
   
    }
    return false;
    
 }
}


function vratiPresjek(pocetak,kraj,zauzecePocetak,zauzeceKraj)
  {
      
     
      var pocetakUnutarIntervala= new Boolean(pocetak >= zauzecePocetak && pocetak <= zauzeceKraj);
      var krajUnutarIntervala= new Boolean(kraj >= zauzecePocetak && kraj <= zauzeceKraj);
      var intervalPrekoIntervala= new Boolean(pocetak <= zauzecePocetak && kraj>=zauzeceKraj);
      var intervalUnutarIntervala=new Boolean(pocetak >= zauzecePocetak && kraj <= zauzeceKraj );
     
     // var presjek= (pocetakUnutarIntervala || krajUnutarIntervala || intervalPrekoIntervala || intervalUnutarIntervala);
        
        if(pocetakUnutarIntervala == true || krajUnutarIntervala==true || intervalPrekoIntervala == true || intervalUnutarIntervala == true) 
         {
             return true;
            }
         else{
          return false;
        }
   }

 function dajDan(datum)
 {
  var x=String(datum);
  var dan=x[0]+x[1];
  var mjesec=x[3]+x[4];
  d=parseInt(dan,10);
  m=parseInt(mjesec,10);

 m--;
  var datum = new Date();
 
  datum.setFullYear(2019, m, d);


var dan=datum.getDay();
dan--;
if(dan==-1)
  dan=6;

 return dan; 
 }

 function dajMjesec(datum)
 {
  var x=String(datum);
  var dan=x[0]+x[1];
  var mjesec=x[3]+x[4];
  d=parseInt(dan,10);
  m=parseInt(mjesec,10);

 m--;
  var datum = new Date();
 
  datum.setFullYear(2019, m, d);


var dan=datum.getDay();
dan--;
if(dan==-1)
  dan=6;

 return m; 
 }

 function Semestar( mjesec) { //provjerava kojem semestru pripada mjesec
  var s;
  if(mjesec>8 || mjesec==0)  { 
      s="zimski";
  }
  else if(mjesec>0 && mjesec<6){
      s="ljetni";
  }   
  return s;        
}