pozoviModul();

function pozoviModul(){
    Pozivi.ucitajJSONPodatke();
    Pozivi.ucitajOsoblje();
};
 