const Sequelize = require("sequelize");

// Termin{id,redovni:boolean, dan:integer, datum:string, semestar:integer,pocetak:time, kraj:time}

/* prvi nacin 
module.exports = function(sequelize,DataTypes){
    const Termin = sequelize.define("Termin",{
		id:Sequelize.INTEGER,  // provjeriti
        redovni:Sequelize.BOOLEAN,
		dan:Sequelize.INTEGER,
		datum:Sequelize.STRING,
        semestar:Sequelize.INTEGER,
		pocetak:Sequelize.TIME,
		kraj:Sequelize.TIME
    })
    return Termin;
}; */

/*drugi nacin */
module.exports = function(sequelize, DataTypes) {
    var Termin = sequelize.define('Termin', {
        id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        redovni: {
            type: Sequelize.BOOLEAN,
			 allowNull: false
        },
        dan: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
		datum: {
            type: Sequelize.STRING(20),
            allowNull: true
        },
		semestar: {
            type: Sequelize.STRING(20), /*NOTE: Iako je navedeno da semestar bude INTEGER, promijenjeno na STRING s obzirom da u bazi treba pisati zimski */
            allowNull: true
        },
		pocetak: {
            type: Sequelize.TIME,
            allowNull: false
        },
		kraj: {
            type: Sequelize.TIME,
            allowNull: false
        }
    });	
    return Termin;
};