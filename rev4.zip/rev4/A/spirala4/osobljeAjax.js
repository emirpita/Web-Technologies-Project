var OsobljeAjax = (function() {
  var konstruktor = function(sadrzajId) {
    function osvjezi() {
      function reqListener () {
        sadrzajId.text = this.responseText;
      }

      var oReq = new XMLHttpRequest();
      oReq.addEventListener("load", reqListener);
      oReq.open("GET", "http://localhost:8080/osobe");
      oReq.send();
    }

    osvjezi();

    return {
      osvjezi: osvjezi
    };
  }

  return konstruktor;
}());
module.exports = OsobljeAjax;