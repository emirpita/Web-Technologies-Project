const Sequelize = require("sequelize");

// Osoblje{id,ime:string,prezime:string,uloga:string}

/* prvi nacin 
module.exports = function(sequelize,DataTypes){
    const Osoblje = sequelize.define("osoblje",{
		id:Sequelize.INTEGER,  // provjeriti
        ime:Sequelize.STRING,
		prezime:Sequelize.STRING,
		uloga:Sequelize.STRING
    })
    return Osoblje;
};*/

/*drugi nacin */
module.exports = function(sequelize, DataTypes) {
    var Osoblje = sequelize.define('Osoblje', {
        id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        ime: {
            type: Sequelize.STRING(20),
            allowNull: false
        },
		prezime: {
            type: Sequelize.STRING(20),
            allowNull: false
        },
		uloga: {
            type: Sequelize.STRING(20),
            allowNull: false
        }
    });
    return Osoblje;
};