
let assert = chai.assert;
let kalendarRef = document.getElementsByClassName("kalendar_mjesec");
describe('Kalendar', function() {
describe('obojiZauzeca()', function() {
		it('Broj dana u Februraru je 28', function() {
		 Kalendar.iscrtajKalendar(kalendarRef,1);
		 Kalendar.obojiZauzeca(kalendarRef, 1, "VA-01", "13:59", "14:59");
		 
		let dan_zaglavlje = document.querySelectorAll(".sedmica .dan_zaglavlje");
		let dan = document.querySelectorAll(".sedmica .dan");
		let brojac_dana = 0;
		let item = 1;
		
		for (let i = 0; i <dan_zaglavlje.length; i++) { 
			if (dan[i].style.visibility == "visible" ) brojac_dana++;
		}
		assert.equal(brojac_dana,28,"Broj dana u Februraru je 28");

		}); 		
		it('Pozivanje obojiZauzeca kada podaci nisu učitani: očekivana vrijednost da se ne oboji niti jedan dan', function() {
		 Kalendar.obojiZauzeca(kalendarRef, 10, "VA-01", "13:59", "14:59");
		 
		let dan_zaglavlje = document.querySelectorAll(".sedmica .dan_zaglavlje");
		let dan_sadrzaj = document.querySelectorAll(".sedmica .dan_sadrzaj");
		
		for (let i = 0; i <dan_zaglavlje.length; i++) { 
			assert.equal(dan_sadrzaj[i].style.backgroundColor == "green","Nijedan dan nije obojen");
		}

		}); 		
		it('Pozivanje obojiZauzeca gdje u zauzećima postoje duple vrijednosti za zauzeće istog termina: očekivano je da se dan oboji bez obzira što postoje duple vrijednosti', function() {

		 Kalendar.obojiZauzeca(kalendarRef, 10, "VA-01", "13:59", "14:59");
		 
		let dan_zaglavlje = document.querySelectorAll(".sedmica .dan_zaglavlje");
		let dan_sadrzaj = document.querySelectorAll(".sedmica .dan_sadrzaj");

		assert.ok(dan_sadrzaj[10].style.backgroundColor != "green","Dan je obojen");
		}); 
		it('Dva puta uzastopno pozivanje obojiZauzece: očekivano je da boja zauzeća ostane ista', function() {
		 var vanredna1 = {datum:"11.12.2019", pocetak:"15:00", kraj:"17:00", naziv: "MA", predavac:"Imenko Prezimenko"};
		 var vanredna2 = {datum:"13.12.2019", pocetak:"15:00", kraj:"17:00", naziv: "MA", predavac:"Imenko Prezimenko"};
		 Kalendar.obojiZauzeca(kalendarRef, 11, vanredna1.naziv, vanredna1.pocetak, vanredna1.kraj);
		 Kalendar.obojiZauzeca(kalendarRef, 11, vanredna2.naziv, vanredna2.pocetak, vanredna2.kraj);
		  
		let dan_zaglavlje = document.querySelectorAll(".sedmica .dan_zaglavlje");
		let dan_sadrzaj = document.querySelectorAll(".sedmica .dan_sadrzaj");
		let brojac_dana = 0;
		
		for (let i = 0; i <dan_zaglavlje.length; i++) { 
			if (dan_sadrzaj[i].style.backgroundColor == "red") brojac_dana++;
		}
		if(brojac_dana==28) assert.ok(true,"Boja zauzeća ostane ista");

		}); 
		it('Pozivanje ucitajPodatke, obojiZauzeca, ucitajPodatke - drugi podaci, obojiZauzeca: očekivano da se zauzeća iz prvih podataka ne ostanu obojena, tj. primjenjuju se samo posljednje učitani podaci', function() {
		 var periodicna1 = {dan: 1, semestar : "zimski", pocetak: "13:59", kraj:"14:59", naziv: "VA-01", predavac:"Ime Prezi"};
		 var periodicna2 = {dan: 4, semestar : "zimski", pocetak: "13:59", kraj:"14:59", naziv: "VA-01", predavac:"Ime Prezi"};
		 var periodicna3 = {dan: 3, semestar : "zimski", pocetak: "13:59", kraj:"14:59", naziv: "VA-01", predavac:"Ime Prezi"};
		 var periodicna4 = {dan: 4, semestar : "zimski", pocetak: "13:59", kraj:"14:59", naziv: "VA-01", predavac:"Ime Prezi"};
		 var periodicna5 = {dan: 5, semestar : "zimski", pocetak: "13:59", kraj:"14:59", naziv: "VA-01", predavac:"Ime Prezi"};
		 var periodicna6 = {dan: 0, semestar : "zimski", pocetak: "13:59", kraj:"14:59", naziv: "VA-01", predavac:"Ime Prezi"};
		 var vanredna1 = {datum:"04.09.2019", pocetak:"15:00", kraj:"17:00", naziv: "MA", predavac:"Imenko Prezimenko"};
		 Kalendar.iscrtajKalendar(kalendarRef,9);
		 Kalendar.ucitajPodatke(periodicna1, vanredna1)
		 Kalendar.obojiZauzeca(kalendarRef, 9, "VA-01",  periodicna1.pocetak, periodicna1.kraj);
		 Kalendar.ucitajPodatke(periodicna2, vanredna1)
		 Kalendar.obojiZauzeca(kalendarRef, 9, "VA-01",  periodicna1.pocetak, periodicna1.kraj);
		  
		let dan_zaglavlje = document.querySelectorAll(".sedmica .dan_zaglavlje");
		let dan_sadrzaj = document.querySelectorAll(".sedmica .dan_sadrzaj");
		
		for (let i = 0; i <dan_zaglavlje.length; i++) { 
			assert.ok(dan_sadrzaj[1].style.backgroundColor == "green","Svi dani su obojeni");
		}
		}); 		
		it('Pozivanje obojiZauzece kada u podacima postoji periodično zauzeće za drugi semestar: očekivano je da se ne oboji zauzeće', function() {
		 var periodicna1 = {dan: 1, semestar : "ljetni", pocetak: "13:59", kraj:"14:59", naziv: "VA-01", predavac:"Ime Prezi"};
		 var vanredna1 = {datum:"04.09.2019", pocetak:"15:00", kraj:"17:00", naziv: "MA", predavac:"Imenko Prezimenko"};
		 Kalendar.iscrtajKalendar(kalendarRef,3);
		 Kalendar.ucitajPodatke(periodicna1, vanredna1)
		 Kalendar.obojiZauzeca(kalendarRef, 3, "VA-01",  periodicna1.pocetak, periodicna1.kraj);
		  
		let dan_zaglavlje = document.querySelectorAll(".sedmica .dan_zaglavlje");
		let dan_sadrzaj = document.querySelectorAll(".sedmica .dan_sadrzaj");
		
		for (let i = 0; i <dan_zaglavlje.length; i++) { 
			assert.ok(dan_sadrzaj[i].style.backgroundColor == "green","Zauzece nije obojeno");
		}
		}); 		
		}); 
 describe('iscrtajKalendar()', function() {
		it('Pozivanje iscrtajKalendar za mjesec sa 30 dana: očekivano je da se prikaže 30 dana', function() {
		 Kalendar.iscrtajKalendar(kalendarRef,3);
		 
		 let dan_zaglavlje = document.querySelectorAll(".sedmica .dan_zaglavlje");
		 let dan = document.querySelectorAll(".sedmica .dan");
		 let brojac_dana = 0;
		 
		for (let i = 0; i <dan_zaglavlje.length; i++) { 
			if (dan[i].style.visibility == "visible" ) {
			  brojac_dana++;
			}
		}
		if (brojac_dana==30) assert.equal(brojac_dana, 30,"Očekivano je da mjesec april ima 30 dana");

		}); 
		it('Pozivanje iscrtajKalendar za mjesec sa 31 dan: očekivano je da se prikaže 31 dan', function() {
		 Kalendar.iscrtajKalendar(kalendarRef,4);
		 
		 let dan_zaglavlje = document.querySelectorAll(".sedmica .dan_zaglavlje");
		 let dan = document.querySelectorAll(".sedmica .dan");
		 let brojac_dana = 0;
		 
		for (let i = 0; i <dan_zaglavlje.length; i++) { 
			if (dan[i].style.visibility == "visible" ) {
			  brojac_dana++;
			}
		}
		if (brojac_dana==31) assert.equal(brojac_dana, 31,"Očekivano je da mjesec maj ima 31 dan");

		}); 
		it('Pozivanje iscrtajKalendar za trenutni mjesec: očekivano je da je 1. dan u petak', function() {
		 Kalendar.iscrtajKalendar(kalendarRef,10);
		 
		 let dan_zaglavlje = document.querySelectorAll(".sedmica .dan_zaglavlje");
		 let dan = document.querySelectorAll(".sedmica .dan");
		 let prviDan = 1;
		 
		 for (let i = 0; i <dan_zaglavlje.length; i++) { 
			 if(dan_zaglavlje[i].innerHTML == prviDan) { 
					assert.ok(dan[4].style.visibility== "visible", "Očekivano je da je 1. dan u petak za trenutni mjesec");
				}
		 }
		}); 
		it('Pozivanje iscrtajKalendar za trenutni mjesec: očekivano je da je 30. dan u subotu', function() {
		 Kalendar.iscrtajKalendar(kalendarRef,10);
		 
		 let dan_zaglavlje = document.querySelectorAll(".sedmica .dan_zaglavlje");
		 let dan = document.querySelectorAll(".sedmica .dan");
		 let zadnjiDan = 30;
		 
		for (let i = 0; i <dan_zaglavlje.length; i++) { 
			if (dan_zaglavlje[i].innerHTML == zadnjiDan) {		
					assert.ok(dan[5].style.visibility== "visible","Očekivano je da je 30. dan u subotu za trenutni mjesec");
			}
		}
		}); 
		it('Pozivanje iscrtajKalendar za januar: očekivano je da brojevi dana idu od 1 do 31 počevši od utorka', function() {
		 Kalendar.iscrtajKalendar(kalendarRef,0);
		 
		 let dan_zaglavlje = document.querySelectorAll(".sedmica .dan_zaglavlje");
		 let dan = document.querySelectorAll(".sedmica .dan");
		 let brojac_dana = 0;
		 let prviDan = 1;
		 let zadnjiDan = 31;
		 
		for (let i = 0; i <dan_zaglavlje.length; i++) { 
			if (dan[i].style.visibility== "visible" ) {
			  brojac_dana++;
			}
		}
		
		for (let i = 0; i <dan_zaglavlje.length; i++) { 
			if (dan[1].style.visibility== "visible" && dan_zaglavlje[i].innerHTML == prviDan) {
				assert.ok(brojac_dana==31,"Očekivano je da januar mjesec ima 31. dan, počevši od utorka");
			}
		}
		}); 
		it('Pozivanje iscrtajKalendar za juli: očekivano je da je broj dana 31', function() {
		 Kalendar.iscrtajKalendar(kalendarRef,6);
		 
		let dan_zaglavlje = document.querySelectorAll(".sedmica .dan_zaglavlje");
		let dan = document.querySelectorAll(".sedmica .dan");
		let brojac_dana = 0;
		let item = 1;
		
		for (let i = 0; i <dan_zaglavlje.length; i++) { 
			if (dan[i].style.visibility == "visible" ) brojac_dana++;
		}
		assert.equal(brojac_dana,31,"Broj dana u julu je 31");

		}); 
		it('Pozivanje iscrtajKalendar za decembar: očekivano je da je prvi dan u nedjelju', function() {
		 Kalendar.iscrtajKalendar(kalendarRef,11);
		 
		let dan_zaglavlje = document.querySelectorAll(".sedmica .dan_zaglavlje");
		let dan = document.querySelectorAll(".sedmica .dan");
		let brojac_dana = 0;
		let prviDan = 1;
		
		for (let i = 0; i <dan_zaglavlje.length; i++) { 
			if(dan_zaglavlje[i].innerHTML == prviDan) { 
				assert.ok(dan[6].style.visibility== "visible", "Očekivano je da je 1. dan u nedjelju za mjesec decembar");
			}
		}

		}); 
	}); 
});