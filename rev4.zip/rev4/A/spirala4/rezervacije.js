const Sequelize = require("sequelize");

//  Rezervacija{id,termin:integer FK UNIQUE,sala:integer FK,osoba:integer FK}

/* prvi nacin 
module.exports = function(sequelize,DataTypes){
    const Rezervacija = sequelize.define("rezervacija",{
		id:Sequelize.INTEGER,  // provjeriti
        termin:Sequelize.INTEGER,
		sala:Sequelize.INTEGER,
        osoba:Sequelize.INTEGER,
    })
    return Rezervacija;
}; */

/*drugi nacin */
module.exports = function(sequelize, DataTypes) {
    var Rezervacija = sequelize.define('Rezervacija', {
        id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
		// U nastavku kod koji je rijesen u db.js sa relacijama
       /* termin: {
            type: Sequelize.INTEGER,
            unique: true,
			allowNull: false,
			references: {
				model: 'termins', // 'termin' refers to table name
				key: 'id', // 'id' refers to column name in termin table
			}
        },
        sala: {
            type: Sequelize.INTEGER,
			allowNull: false,
			references: {
				model: 'salas', // 'sala' refers to table name
				key: 'id', // 'id' refers to column name in sala table
			}
        },
		osoba: {
            type: Sequelize.INTEGER,
			allowNull: false,
			references: {
				model: 'osobljes', // 'osoblje' refers to table name
				key: 'id', // 'id' refers to column name in osoblje table
			}
        }*/
    });	
    return Rezervacija;
};