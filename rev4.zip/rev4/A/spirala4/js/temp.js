let Pozivi = (function(){

function pocetnaPozivImpl(){
	var ajax = new XMLHttpRequest();
	ajax.onreadystatechange = function() { // Anonimna funkcija
		if (ajax.readyState == 4 && ajax.status == 200)
			document.getElementById("sadrzajId").innerHTML = ajax.responseText;
		if (ajax.readyState == 4 && ajax.status == 404)
			document.getElementById("sadrzajId").innerHTML = "Greska: nepoznat URL";
	}
	ajax.open("GET", "http://localhost:8080/pocetna.html", true);
	ajax.send();
}

function salePozivImpl(){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() { // Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200)
            document.getElementById("sadrzajId").innerHTML = ajax.responseText;
        if (ajax.readyState == 4 && ajax.status == 404)
            document.getElementById("sadrzajId").innerHTML = "Greska: nepoznat URL";
    }
    ajax.open("GET", "http://localhost:8080/sale.html", true);
    ajax.send();
}

function unosPozivImpl(){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() { // Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200)
            document.getElementById("sadrzajId").innerHTML = ajax.responseText;
        if (ajax.readyState == 4 && ajax.status == 404)
            document.getElementById("sadrzajId").innerHTML = "Greska: nepoznat URL";
    }
    ajax.open("GET", "http://localhost:8080/unos.html", true);
    ajax.send();
}

function rezervacijaPozivImpl(){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {		// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200)
		{  
			var response = JSON.parse(ajax.responseText);
			var periodicna = response.periodicna;
			var vanredna = response.vanredna;
			console.log(periodicna);
			var trenutni = new Date();
			var godina = 2020;
			var mjesec = trenutni.getMonth();
			Kalendar.ucitajPodatke(periodicna[0],vanredna[0]);
			Kalendar.obojiZauzeca(document.getElementsByClassName("kalendar_mjesec"), mjesec, periodicna.sala, periodicna.pocetak, periodicna.kraj);
		}
        if (ajax.readyState == 4 && ajax.status == 404)
            document.getElementById("sadrzajId").innerHTML = "Greska: nepoznat URL";
    }
    ajax.open("GET", "http://localhost:8080/zauzeca.json", true);
    ajax.send();
}

function osobePozivImpl(){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() { // Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200)
            document.getElementById("sadrzajId").innerHTML = ajax.responseText;
        if (ajax.readyState == 4 && ajax.status == 404)
            document.getElementById("sadrzajId").innerHTML = "Greska: nepoznat URL";
    }
    ajax.open("GET", "http://localhost:8080/osobe.html", true);
    ajax.send();
}

var cached = {};

function ispisiHtml(value) {
	var html = "<div>";
	for (x in value) {
		html += "<img class='fetch' src=" + value[x] + ">";
	}
	html = html + "</div>";
	document.getElementById("items").innerHTML = html;
}

function ispisiTable(value) {
	/*var html = "<tr>";

	html += "<td id='osobe'>" + value.Osoblje.ime + " " + value.Osoblje.prezime + "</td>";
	html += "<td id='sala'>" + value.Sala.naziv + "</td>";
	
	html = html + "</tr>";*/
	//document.getElementById("items").innerHTML = html;
	//document.getElementById("items").append(html);
	var table = document.getElementById("items");
	var row = table.insertRow(0);
	var cell1 = row.insertCell(0);
	var cell2 = row.insertCell(1);
	cell1.innerHTML = value.Osoblje.ime + " " + value.Osoblje.prezime;
	cell2.innerHTML = value.Sala.naziv;
}

function unesiOsobeImpl() {
	var ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() { // Anonimna funkcija
			if (ajax.readyState == 4 && ajax.status == 200) {
				var response = JSON.parse(ajax.responseText);
				for(x in response){
					document.getElementById('osoblje').add(new Option(response[x]));
				}		
		}
	};
	ajax.open("GET", "http://localhost:8080/osoblje", true);
    ajax.send();
}

function dohvatiSaleImpl() {
	var ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() { // Anonimna funkcija
			if (ajax.readyState == 4 && ajax.status == 200) {
				var response = JSON.parse(ajax.responseText);
				for(x in response){
					document.getElementById('sala').add(new Option(response[x]));
				}		
		}
	};
	ajax.open("GET", "http://localhost:8080/sala", true);
    ajax.send();
}

function prikaziOsobeImpl() {
	var ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() { // Anonimna funkcija
			if (ajax.readyState == 4 && ajax.status == 200) {
				var response = JSON.parse(ajax.responseText);
				for(var i=0; i<response.length; i++){
					ispisiTable(response[i]);
				}		
		}
	};
	ajax.open("GET", "http://localhost:8080/osobe", true);
	ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    ajax.send();
}
	
function photoFetchImpl(offset){
	
	if (offset==0) {
		document.getElementById("left").disabled = true;
		document.getElementById("right").disabled = false;
	}	
	else if (offset>0) {
		document.getElementById("left").disabled = false;
		document.getElementById("right").disabled = false;
	}		
	if(cached[offset]) {
		ispisiHtml(cached[offset]);
		return;
	}
	var ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() { // Anonimna funkcija
			if (ajax.readyState == 4 && ajax.status == 200) {
				var response = JSON.parse(ajax.responseText);
				cached[offset]=response;
				ispisiHtml(response);
			if (response.length<3) {
				document.getElementById("right").disabled = true;
			}
		}
	};
	ajax.open("GET", "http://localhost:8080/slike.json?offset=" + offset, true);
	ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    ajax.send();
}

function dohvatiZauzecaImpl(){
        ajax.onreadystatechange = function(){
            if (ajax.readyState == 4 && ajax.status == 200){
                let odgovor = JSON.parse(ajax.responseText);
                Kalendar.ucitajPodatke(odgovor.periodicna, odgovor.vanredna);
            }
            else if (ajax.readyState == 4){
                console.log(ajax.status + ": " + ajax.statusText);
            }
        }
        ajax.open("GET", "http://localhost:8080/zauzeca", true);
        ajax.send();
    }

return {
	pocetnaPoziv : pocetnaPozivImpl,
	salePoziv : salePozivImpl,
	unosPoziv : unosPozivImpl,
	rezervacijaPoziv : rezervacijaPozivImpl,
	osobePoziv : osobePozivImpl,
	unesiOsobe : unesiOsobeImpl,
	dohvatiZauzeca : dohvatiZauzecaImpl,
	prikaziOsobe : prikaziOsobeImpl,
	dohvatiSale : dohvatiSaleImpl,
	photoFetch : photoFetchImpl
}
}());