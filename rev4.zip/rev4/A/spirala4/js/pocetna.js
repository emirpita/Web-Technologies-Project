window.onload = function () {
	Pozivi.pocetnaPoziv();
	Pozivi.photoFetch(0);
}

var value = 0;

function fetchPhoto() {
  value = value + 3;
  Pozivi.photoFetch(value);
}

function fetchOldPhoto() {
  value = value - 3;
  Pozivi.photoFetch(value);
}
