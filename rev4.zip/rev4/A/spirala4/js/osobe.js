function osobeFunction() {
  Pozivi.osobePoziv();
  Pozivi.prikaziOsobe();
}