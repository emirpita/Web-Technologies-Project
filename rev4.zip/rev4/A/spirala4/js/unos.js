function unosFunction() {
  Pozivi.unosPoziv();
}