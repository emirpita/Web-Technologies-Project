const assert = require('assert');
const chai = require("chai");
const chaiHttp = require("chai-http");

chai.use(chaiHttp);
let should=chai.should();
const BAZ_URL="http://localhost:8080";

// Test provjeri da li se dohvataju stranice
describe('Test dohvati sve stranice',function(done){
    let stranice=["pocetna.html","sale.html","unos.html","rezervacija.html","osobe.html"];
    for(str in stranice){
		var stranica = stranice[str];
		it(`dohvata ${stranica}`,function(done){
			console.log(stranica);
			chai.request(BAZ_URL).get(`/${stranica}`).end(function(err,res){
					if(err) {
					return done(err);
				}
				res.text.should.match(/<!DOCTYPE html>/);
				res.should.have.header('Content-Type',/text\/html.+/);
				done();
			});
		});
    }
});

// Test provjeri da li ce se dohvatiti osoblje
describe('Vraca osoblje',function(done){
    it('vraća  osoblje',function(done){
        chai.request(BAZ_URL).get('/osoblje').end(function(err,res){
			if(err) {
					return done(err);
				}
            res.should.have.status(200);
            res.should.have.header("Content-Type",/application\/json/);
            done();
        });
    });
});

// Test provjeri da li ce se dohvatiti sale
describe('Vraca sale',function(done){
    it('vraća  sale',function(done){
        chai.request(BAZ_URL).get('/sala').end(function(err,res){
			if(err) {
					return done(err);
				}
            res.should.have.status(200);
            res.should.have.header("Content-Type",/application\/json/);
            done();
        });
    });
});


// Test provjeri da li ce se dohvatiti zauzeca
describe('Vraca zauzeca',function(done){
    it('vraća  zauzeca',function(done){
        chai.request(BAZ_URL).get('/zauzeca').end(function(err,res){
			if(err) {
					return done(err);
				}
            res.should.have.status(200);
            res.should.have.header("Content-Type",/application\/json/);
            done();
        });
    });
});

