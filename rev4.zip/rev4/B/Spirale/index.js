const express = require("express");
const fs = require("fs");
const bodyParser = require("body-parser");
const app = express();
const PORT = 8080;
const kreiranjeInicijalizacijaBaze = require("./priprema.js");
const db = require("./db.js");

kreiranjeInicijalizacijaBaze();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname));

app.listen(PORT, () => {
  console.log(`Server started at port ${PORT}...`);
  console.log("-------------------------------");
});

// Rute

app.get("/", function(req, res) {
  res.redirect("/rezervacija");
});

app.get("/osoblje", function(req, res) {
  db.osoblje.findAll().then(function(osoblje) {
    result = [];
    osoblje.forEach(o => result.push(o.dataValues));
    res.send(result);
  });
});

app.get("/sale", function(req, res) {
  res.sendFile(__dirname + "/sale.html");
});

app.get("/unos", function(req, res) {
  res.sendFile(__dirname + "/unos.html");
});

app.get("/rezervacija", function(req, res) {
  res.sendFile(__dirname + "/rezervacija.html");
});

app.get("/pocetna", function(req, res) {
  res.sendFile(__dirname + "/pocetna.html");
});

// Zadatak 1  - slanje podataka o zauzecima
app.get("/zauzeca", function(req, res) {
  res.sendFile(__dirname + "/zauzeca.json");
});

// Zadatak 3 -

app.post('/rezervacija-periodicna', function (req, res) {
  let zauzece = req.body;
  if (zauzeceOk(zauzece,'p')) {
    fs.readFile(__dirname + '/zauzeca.json', function (err, data) {
      let json = JSON.parse(data);
      let periodicna = json.periodicna;
      let vanredna = json.vanredna;
      let jeZauzeto = false;
      // Provjera na serveru periodicnih i vanrednih
      for (let i = 0; i < periodicna.length; i++) {
        if (zauzecaSePoklapaju(zauzece,periodicna[i])) {
          jeZauzeto = true;
          break;
        }
      }
      for (let i = 0; i < vanredna.length; i++) {
        if (zauzecaSePoklapaju(zauzece,vanredna[i])) {
          jeZauzeto = true;
          break;
        }
      }
      if (!jeZauzeto) {
        // Upisujemo zauzece
        periodicna.push(zauzece);
        fs.writeFile(__dirname + '/zauzeca.json', JSON.stringify(json), (err) => {
          if (err) throw err;
          // Slanje svih zauzeca
          res.json(json);
        });
      }
      else {
        // Slanje poruke o greski
        res.status(400).send({message:"Nije moguce izvrisiti periodicno zauzece jer je termin vec zauzet!"});
      }
    })
  }
  else {
    res.status(400).send({message:"Format zauzeca nije validan!"});
  }
});

app.post("/rezervacija-vanredna", function(req, res) {
  let zauzece = req.body;
  if (zauzeceOk(zauzece, "v")) {
    fs.readFile(__dirname + "/zauzeca.json", function(err, data) {
      let json = JSON.parse(data);
      let vanredna = json.vanredna;
      let periodicna = json.periodicna;
      let jeZauzeto = false;
      // Provjera na serveru periodicnih i vanrednih
      for (let i = 0; i < periodicna.length; i++) {
        if (zauzecaSePoklapaju(zauzece, periodicna[i])) {
          jeZauzeto = true;
          break;
        }
      }
      for (let i = 0; i < vanredna.length; i++) {
        if (zauzecaSePoklapaju(zauzece, vanredna[i])) {
          jeZauzeto = true;
          break;
        }
      }
      if (!jeZauzeto) {
        // Upisujemo zauzece
        vanredna.push(zauzece);
        fs.writeFile(__dirname + "/zauzeca.json", JSON.stringify(json), err => {
          if (err) throw err;
          // Slanje svih zauzeca
          res.json(json);
        });
      } else {
        // Slanje poruke o greski
        let poruka = `Nije moguce izabrati salu ${zauzece.naziv} za navedeni datum ${zauzece.datum} i termin od ${zauzece.pocetak} do ${zauzece.kraj}!`;
        res.status(400).send({ message: poruka });
      }
    });
  } else {
    res.status(400).send({ message: "Format zauzeca nije validan!" });
  }
});

function datumOk(datum) {
  const regex = RegExp("^([0-3][0-9]).([0-1][0-9]).([0-9]{4})$");
  if (regex.test(datum)) {
    const d = datum.split(".");
    return Date.parse(`${d[2]}-${d[1]}-${d[0]}`) ? true : false;
  }
  return false;
}

function formirajDatum(dan, mjesec, godina) {
  mjesec++;
  return (
    "" +
    (dan < 10 ? "0" + dan : dan) +
    "." +
    (mjesec < 10 ? "0" + mjesec : mjesec) +
    "." +
    godina
  );
}

function vrijemeOk(vrijeme) {
  const regex = RegExp("^([0-1][0-9]|2[0-3]):[0-5][0-9]$");
  return regex.test(vrijeme);
}

function zauzeceOk(zauzece, tip) {
  if (tip === "p" || tip === "v") {
    if (
      !vrijemeOk(zauzece.pocetak) ||
      !vrijemeOk(zauzece.kraj) ||
      zauzece.kraj <= zauzece.pocetak
    ) {
      return false;
    }
    if (tip === "p") {
      if (
        zauzece.dan < 0 ||
        zauzece.dan > 6 ||
        ["zimski", "ljetni"].indexOf(zauzece.semestar) == -1
      )
        return false;
    }
    if (tip === "v") {
      if (!datumOk(zauzece.datum)) return false;
    }
    return true;
  }
}

function periodicnoPeriodicnoPoklapanje(zauzeceNovo, zauzeceStaro) {
  return (
    zauzeceNovo.dan === zauzeceStaro.dan &&
    zauzeceNovo.semestar === zauzeceStaro.semestar &&
    zauzeceNovo.naziv === zauzeceStaro.naziv &&
    !(
      zauzeceNovo.pocetak >= zauzeceStaro.kraj ||
      zauzeceNovo.kraj <= zauzeceStaro.pocetak
    )
  );
}

function vanrednoVanrednoPoklapanje(zauzeceNovo, zauzeceStaro) {
  return (
    zauzeceNovo.naziv === zauzeceStaro.naziv &&
    zauzeceNovo.datum === zauzeceStaro.datum &&
    !(
      zauzeceNovo.pocetak >= zauzeceStaro.kraj ||
      zauzeceNovo.kraj <= zauzeceStaro.pocetak
    )
  );
}

function periodicnoVanrednoPoklapanje(periodicno, vanredno) {
  // Pretvorimo vanredno u periodicno
  let d = vanredno.datum.split(".").map(e => {
    return parseInt(e);
  });
  let mjesecP = d[1] - 1;
  let danP = (new Date(d[2], mjesecP, d[0]).getDay() + 6) % 7;
  let semestarP = [0, 9, 10, 11].indexOf(mjesecP) != -1 ? "zimski" : "";
  if (semestarP === "") {
    semestarP = [1, 2, 3, 4, 5].indexOf(mjesecP) != -1 ? "ljetni" : "izmedju";
  }
  // Kvazi periodicna rezervacija
  let p2 = {
    dan: danP,
    semestar: semestarP,
    pocetak: vanredno.pocetak,
    kraj: vanredno.kraj,
    naziv: vanredno.naziv,
    predavac: vanredno.predavac
  };
  return periodicnoPeriodicnoPoklapanje(periodicno, p2);
}

function zauzecaSePoklapaju(zauzeceNovo, zauzeceStaro) {
  let tipNovo = Object.keys(zauzeceNovo).length == 6 ? "p" : "v";
  let tipStaro = Object.keys(zauzeceStaro).length == 6 ? "p" : "v";
  // Periodicna, Periodicna
  if (tipNovo === "p" && tipStaro === "p") {
    return periodicnoPeriodicnoPoklapanje(zauzeceNovo, zauzeceStaro);
  }
  // Vanredna, Vanredna
  if (tipNovo === "v" && tipStaro === "v") {
    return vanrednoVanrednoPoklapanje(zauzeceNovo, zauzeceStaro);
  }
  // Periodicna, Vanredna
  if (tipNovo === "p" && tipStaro === "v") {
    return periodicnoVanrednoPoklapanje(zauzeceNovo, zauzeceStaro);
  }
  // Vanredna, Periodicna
  return periodicnoVanrednoPoklapanje(zauzeceStaro, zauzeceNovo);
}
