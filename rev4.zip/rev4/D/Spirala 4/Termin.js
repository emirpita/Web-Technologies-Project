const Sequelize = require("sequelize");

module.exports = function(sequelize,DataTypes){
    const Termin = sequelize.define('Termin', {
        
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        redovni: {
           type: Sequelize.BOOLEAN
        },
        dan: {
            allowNull: true,
           type: Sequelize.INTEGER
        },
        datum: {
            allowNull: true,
           type: Sequelize.STRING
        },
        semestar: {
            allowNull: true,
           type: Sequelize.STRING
        },
        pocetak:{
            allowNull: true,
           type: Sequelize.TIME
        },
        kraj: {
            allowNull: true,
            type: Sequelize.TIME
        }
    },{
        timestamps: false,
            freezeTableName: true,
            paranoid: true,
            underscored: true

});
    return Termin;
};