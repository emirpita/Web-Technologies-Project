let assert = chai.assert;
describe('Kalendar', function() {
        
 describe('iscrtajKalendar()', function() {
    it('zadnji subota', function() {
        Kalendar.iscrtajKalendar(document.getElementsByClassName("podloga"), 10);
        kalendarRef = document.getElementsByClassName("podloga");
        var deca = kalendarRef[0].children;  
        var divContainer = deca[1];
        var sljedece = divContainer.children;
       
        var istina = 0;
        if(sljedece[5].children[9].innerHTML == "30") {
                    istina = 1;
        }
            

        
    
        assert.equal(istina, 1,"Zadnji dan je subota");
      });

    it('petak je zadnji dan', function() {
        Kalendar.iscrtajKalendar(document.getElementsByClassName("podloga"), datumZaZadatak.getMonth());
       
        Kalendar.iscrtajKalendar(document.getElementsByClassName("podloga"), 10);
        kalendarRef = document.getElementsByClassName("podloga");
        var deca = kalendarRef[0].children;  
        var divContainer = deca[1];
        var sljedece = divContainer.children;
       
        var istina = 0;
        if(sljedece[4].children[1].innerHTML == "1") {
                    istina = 1;
        }

        assert.equal(istina, 1,"Prvi dan je petak");
    });


    it('za januar provjera', function() {
        Kalendar.iscrtajKalendar(document.getElementsByClassName("podloga"), 0);
       
        
        kalendarRef = document.getElementsByClassName("podloga");
        var deca = kalendarRef[0].children;  
        var divContainer = deca[1];
        var sljedece = divContainer.children;
        var br = 0;
        var istina = 0;
    
        if(sljedece[3].children[9].innerHTML == "31" && sljedece[1].children[1].innerHTML == "1") {
            istina = 1;
        }

       

        assert.equal(istina, 1,"Broj dana treba biti 31 i prvi dan je utorak");
    });

    it('30 dana za novembar', function() {
        Kalendar.iscrtajKalendar(document.getElementsByClassName("podloga"), 10);
       
        
        kalendarRef = document.getElementsByClassName("podloga");
        var deca = kalendarRef[0].children;  
        var divContainer = deca[1];
        var sljedece = divContainer.children;
        var br = 0;
        var istina = 0;
        
        if(sljedece[5].children[9].innerHTML == "30") {
            istina = 1;
        }
        assert.equal(istina, 1,"Broj dana treba biti 30");
    });

    

    

    

    it('check if first week is from 1 to 7', function() {
        Kalendar.iscrtajKalendar(document.getElementsByClassName("podloga"), 10);
       
        
        kalendarRef = document.getElementsByClassName("podloga");
        var deca = kalendarRef[0].children;  
        var divContainer = deca[1];
        var sljedece = divContainer.children;
        var br = 0;
        var istina = 0;
        
        if(sljedece[4].children[1].innerHTML == "1" && sljedece[3].children[3].innerHTML == "7") {
            istina = 1;
        }
        assert.equal(istina, 1,"Broj dana treba biti 7");
    });

    it('sredina mjeseca je li 15', function() {
        Kalendar.iscrtajKalendar(document.getElementsByClassName("podloga"), 10);
       
        
        kalendarRef = document.getElementsByClassName("podloga");
        var deca = kalendarRef[0].children;  
        var divContainer = deca[1];
        var sljedece = divContainer.children;
        var br = 0;
        var istina = 0;
        
        if(sljedece[4].children[5].innerHTML == "15") {
            istina = 1;
        }
        assert.equal(istina, 1,"good");
    });

 });

 
 });

