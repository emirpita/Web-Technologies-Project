var http = require('http');
var fs = require('fs');
var url = require('url');
var express = require('express');
var path = require('path');
var procitanFajl = JSON.parse(fs.readFileSync('zauzeca.json', 'utf8'));
var _ = require('underscore');

const db = require('./db.js');
db.sequelize.sync({force: true}).then(function(){
    let promises = [];
    promises.push(db.Osoblje.create({
        ime: "Neko",
        prezime: "Nekić",
        uloga: "profesor"
    }));
    promises.push(db.Osoblje.create({
        ime: "Drugi",
        prezime: "Neko",
        uloga: "asistent"
    }));
    promises.push(db.Osoblje.create({
        ime: "Test",
        prezime: "Test",
        uloga: "asistent"
    }));
    Promise.all(promises).then(osobe => {
        let o1 = osobe.filter(aa => aa.ime == 'Neko')[0];
        let o2 = osobe.filter(aa => aa.ime == 'Drugi')[0];
        let o3 = osobe.filter(aa => aa.ime == 'Test')[0];
        let sale = [];
        sale.push(db.Sala.create({
            naziv: "1-11",
            zaduzenaOsoba: 2
        }));
        sale.push(db.Sala.create({
            naziv: "1-15",
            zaduzenaOsoba: 1
        }));

        Promise.all(sale).then(sale => {
            let sala1 = sale.filter(h => h.naziv == '1-11')[0];
            let sala2 = sale.filter(h => h.naziv == '1-15')[0];
            let termini = [];
            termini.push(db.Termin.create({
                redovni: false,
                dan: null,
                datum: "01.01.2020",
                semestar: null,
                pocetak: "12:00",
                kraj: "13:00"
            }));
            termini.push(db.Termin.create({
                redovni: true,
                    dan: 0,
                    datum: null,
                    semestar: "zimski",
                    pocetak: "13:00",
                    kraj: "14:00"
            }));
            Promise.all(termini).then(termini => {
                t = termini.filter(t => !t.redovni)[0];
                td = termini.filter(t => t.redovni)[0];
                db.Rezervacija.create({}).then(rez => {
                    rez.sala = 1;
                    rez.termin = t.id;
                    rez.osoba = o1.id;
                    rez.save();
                });
                db.Rezervacija.create({}).then(rez => {
                    rez.sala = 1;
                    rez.termin = td.id;
                    rez.osoba = o3.id;
                    rez.save();
                });
            });

        });
    });

});

    var server = express();
    server.use('/static', express.static(path.join(__dirname, 'public')));
    
    server.get('/', function(req, res) {
        console.log(req.url);
            res.sendFile(path.join(__dirname, '/pocetna.html'));  
    });

    server.get('/Slike', (req, res) => {
        fs.readdir([__dirname, '/Slike'].join(''), function (err, files) {
            let naseSlike = [];
            _.each(files, function(imageFIle) {
                let slike = fs.readFileSync([__dirname, '/Slike', '/', imageFIle].join(''));
                slike = "data:image/jpeg;base64," + new Buffer(slike).toString('base64');
                naseSlike.push(slike);
            })
            var kakoSaljemoSlike = JSON.stringify(naseSlike);
            res.writeHead(200, {'Content-Type': 'application/json'});
            res.end(kakoSaljemoSlike);
        })
    });

    server.post('/zauzeca.json', function(req, res) {    
        if(tijelo.predavac == "sdf") {
            res.json(req.body);
            
        } else {
            procitanFajl.vanrednaZauzeca.push(req.body);
            let nasaLinija = JSON.stringify(procitanFajl, null, 2);
            fs.writeFile('zauzeca.json', nasaLinija, function (err) {
                if (err) throw err;
              });
            res.json(nasaLinija);
            
        }
          
    });

    server.get('/zauzeca.json', function(req, res) {
            res.sendFile(path.join(__dirname, '/zauzeca.json'));
    });

    server.get('/pocetna.html', function(req, res) {
            res.sendFile(path.join(__dirname, '/pocetna.html')); 
    });

    server.get('/rezervacija.html', function(req, res) { 
        res.sendFile(path.join(__dirname, '/rezervacija.html'));   
    });

    server.get('/sale.html', function(req, res) {
            res.sendFile(path.join(__dirname, '/sale.html'));  
    });

    server.get('/unos.html', function(req, res) {
            res.sendFile(path.join(__dirname, '/unos.html'));   
    });

    server.get('/#', function(req, res) {
        res.writeHead(200, {'Content-Type': 'application/text'});
        res.write("Prazno za sada");
        res.end();
});

app.post('/rezervisanje', function(req, res) {    
    let tijelo = req.body;
            let pocetak = tijelo.predavac.split(" ");
            var salaKojuStavljamo = tijelo.naziv;
            var semest = "";
            semest = tijelo.datum[3];
            if(semest == "11" || semest == "10" || semest == "9" || semest == "0") {
                semest = "zimski";
            } else if(semest == "2" || semest == "1" || sem == "3" || sem == "5" || sem == "4") {
                semest = "ljetni";
            } else {
                semest = null;
            }
            
                let pr = [];
                pr.push(db.Termin.create({
                    redovni: false,
                    dan: null,
                    datum: tijelo.datum,
                    semestar: semest,
                    pocetak: tijelo.pocetak,
                    kraj: tijelo.kraj
                }));
                Promise.all(pr).then(ter => {
                    ter1 = ter.filter(t => !t.redovni)[0];
                    let pr = [];
                    pr.push(db.Sala.findOne({where: {naziv: salaKojuStavljamo}}));
                    pr.push(db.Osoblje.findOne({where: {ime: pocetak[0]}}));
                    
                    Promise.all(pr).then(nastavak => {
                        var os = nastavak[0].id;
                        var sl = nastavak[1].id;
                        db.Rezervacija.create({}).then(pok => {
                            pok.sala = sl;
                            pok.termin = ter.id;
                            pok.osoba = os;
                            pok.save();
                        });
                    });
                });                         
    
    res.send("odgovor");  
});    


    server.listen(8080);
    



