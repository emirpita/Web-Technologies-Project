let Kalendar = (function(){

    this.periodicnaZauzeca;
    this.vanrednaZauzeca;

    this.datumZaZadatak = new Date();

    function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj) {
        var deca = kalendarRef[0].children;  
        var divContainer = deca[1];
        var sljedece = divContainer.children;
        var pocetakNas = parseInt(pocetak.substring(0, 2));
        var pocetakNas1 = parseInt(pocetak.substring(3, 5));
        var krajNas = parseInt(kraj.substring(0, 2));
        var krajNas1 = parseInt(kraj.substring(3, 5));

        for(var ass = 0; ass < periodicnaZauzeca.length; ass++) {
            if((periodicnaZauzeca[ass].semestar == "ljetni" && (mjesec == 1 || mjesec == 2 || mjesec == 3 || mjesec == 4 || mjesec == 5) || periodicnaZauzeca[ass].semestar == "zimski" && (mjesec == 0 || mjesec == 9 || mjesec == 10 || mjesec == 11)) && sala == periodicnaZauzeca[ass].naziv && (pocetakNas < parseInt(periodicnaZauzeca[ass].pocetak.substring(0, 2))) || (pocetakNas1 < parseInt(periodicnaZauzeca[ass].pocetak.substring(3, 5)) && pocetakNas == parseInt(periodicnaZauzeca[ass].pocetak.substring(0, 2))) && (krajNas > parseInt(periodicnaZauzeca[ass].kraj.substring(0, 2))) || (krajNas1 > parseInt(periodicnaZauzeca[ass].kraj.substring(3, 5)) && krajNas == parseInt(periodicnaZauzeca[ass].kraj.substring(0, 2)))) {
                if(periodicnaZauzeca[ass].dan == 0) {
                    for(var brojbroj = 2; brojbroj <= 13; brojbroj+=2) {
                        if(sljedece[0].children[brojbroj-1].innerHTML == "") continue;
                        sljedece[0].children[brojbroj].style.backgroundColor = "red";
                    }
                } else if(periodicnaZauzeca[ass].dan == 1) {
                    for(var brojbroj = 2; brojbroj <= 13; brojbroj+=2) {
                        if(sljedece[1].children[brojbroj-1].innerHTML == "") continue;
                        sljedece[1].children[brojbroj].style.backgroundColor = "red";
                        
                    }
                } else if(periodicnaZauzeca[ass].dan == 2) {
                    for(var brojbroj = 2; brojbroj <= 13; brojbroj+=2) {
                        if(sljedece[2].children[brojbroj-1].innerHTML == "") continue;
                        sljedece[2].children[brojbroj].style.backgroundColor = "red";
                    }
                } else if(periodicnaZauzeca[ass].dan == 3) {
                    for(var brojbroj = 2; brojbroj <= 13; brojbroj+=2) {
                        if(sljedece[3].children[brojbroj-1].innerHTML == "") continue;
                        sljedece[3].children[brojbroj].style.backgroundColor = "red";
                    }
                } else if(periodicnaZauzeca[ass].dan == 4) {
                    for(var brojbroj = 2; brojbroj <= 13; brojbroj+=2) {
                        if(sljedece[4].children[brojbroj-1].innerHTML == "") continue;
                        sljedece[4].children[brojbroj].style.backgroundColor = "red";
                    }
                } else if(periodicnaZauzeca[ass].dan == 5) {
                    for(var brojbroj = 2; brojbroj <= 13; brojbroj+=2) {
                        if(sljedece[5].children[brojbroj-1].innerHTML == "") continue;
                        sljedece[5].children[brojbroj].style.backgroundColor = "red";
                    }
                } else if(periodicnaZauzeca[ass].dan == 6) {
                    for(var brojbroj = 2; brojbroj <= 13; brojbroj+=2) {
                        if(sljedece[6].children[brojbroj-1].innerHTML == "") continue;
                        sljedece[6].children[brojbroj].style.backgroundColor = "red";
                    }
                }
            }
        }
        
        for(var poki = 0; poki < vanrednaZauzeca.length; poki++) {
            var podatak = vanrednaZauzeca[poki].datum;
            var zaPoredbuD = podatak.substring(0,2);
            var zaPoredbuM = podatak.substring(3,5);
            if(parseInt(zaPoredbuM)-1 == mjesec) {
                for(var k = 0; k < sljedece.length; k++) {
                    for(var divovi = 1; divovi <= 12; divovi++) {
                        if(sljedece[k].children[divovi].innerHTML == parseInt(zaPoredbuD)) {
                            sljedece[k].children[divovi+1].style.backgroundColor = "red";
                        }
                    }
                }
            }   
        }

    }

    function ucitajPodatkeImpl(periodicna, vanredna) {
        periodicnaZauzeca = periodicna;
        vanrednaZauzeca = vanredna;
    } 

    function iscrtajKalendarImpl(kalendarRef, mjesec){
        var deca = kalendarRef[0].children;  
        var divContainer = deca[1];
        var sljedece = divContainer.children;
        

        for(var k = 0; k < sljedece.length; k++) {
            for(var divovi = 1; divovi <= 12; divovi++) {
                sljedece[k].children[divovi].innerHTML = "";
                sljedece[k].children[divovi].style.border = "none";
                sljedece[k].children[divovi].style.backgroundColor = "blue";
            }
        }

        if(mjesec == 12) {
            document.getElementById("imeDugme2").disabled = true;
        } else if(mjesec == -1) {
            document.getElementById("imeDugme1").disabled = true;
        }else if(mjesec == 0) {
            datumZaZadatak.setMonth(mjesec);
            document.getElementById("imeNaKalendaru").innerHTML = "Januar";
            var varijablaZaBrojanjeDana = 0;
            var kopija = 0;
            for(var k = 0; k < sljedece.length; k++) {
                varijablaZaBrojanjeDana++;
                kopija = varijablaZaBrojanjeDana;
                for(var divovi = 1; divovi <= 12; divovi+=2) {
                    
                    if(kopija > 32) {
                        for(var jaj = divovi; jaj <= 12; jaj++) {
                            sljedece[k].children[jaj].innerHTML = "";
                            sljedece[k].children[jaj].style.border = "none";
                            sljedece[k].children[jaj].style.backgroundColor = "blue";
                        }
                        continue;
                    }
                    
                    sljedece[k].children[divovi].innerHTML = kopija-1;
                    sljedece[k].children[divovi].style.border = "1px solid white";
                    sljedece[k].children[divovi+1].style.border = "1px solid white";
                    sljedece[k].children[divovi].style.backgroundColor = "white";
                    sljedece[k].children[divovi+1].style.backgroundColor = "green";
                    kopija+=7;
                }   
            }
            sljedece[0].children[1].innerHTML = "";
            sljedece[0].children[1].style.border = "none";
            sljedece[0].children[1].style.backgroundColor = "blue";
            sljedece[0].children[2].style.border = "none";
            sljedece[0].children[2].style.backgroundColor = "blue";
            
            
            //FEBRUAR
        } else if(mjesec == 1) {
            datumZaZadatak.setMonth(mjesec);
            document.getElementById("imeNaKalendaru").innerHTML = "Februar";
            var varijablaZaBrojanjeDana = 0;
            var kopija = 0;
            for(var k = 0; k < sljedece.length; k++) {
                varijablaZaBrojanjeDana++;
                kopija = varijablaZaBrojanjeDana;
                for(var divovi = 1; divovi <= 12; divovi+=2) {
                    
                    if(kopija > 32) {
                        for(var jaj = divovi; jaj <= 12; jaj++) {
                            sljedece[k].children[jaj].innerHTML = "";
                            sljedece[k].children[jaj].style.border = "none";
                            sljedece[k].children[jaj].style.backgroundColor = "blue";
                        }
                        continue;
                    }
                    
                    sljedece[k].children[divovi].innerHTML = kopija-4;
                    sljedece[k].children[divovi].style.border = "1px solid white";
                    sljedece[k].children[divovi+1].style.border = "1px solid white";
                    sljedece[k].children[divovi].style.backgroundColor = "white";
                    sljedece[k].children[divovi+1].style.backgroundColor = "green";
                    kopija+=7;
                }   
            }
            for(var jhj = 0; jhj < 4; jhj++) {
                    sljedece[jhj].children[1].innerHTML = "";
                    sljedece[jhj].children[1].style.border = "none";
                    sljedece[jhj].children[1].style.backgroundColor = "blue";
                    sljedece[jhj].children[2].style.border = "none";
                    sljedece[jhj].children[2].style.backgroundColor = "blue";
                
            }
            //MART
        } else if(mjesec == 2) {
            datumZaZadatak.setMonth(mjesec);
            document.getElementById("imeNaKalendaru").innerHTML = "Mart";
            var varijablaZaBrojanjeDana = 0;
            var kopija = 0;
            for(var k = 0; k < sljedece.length; k++) {
                varijablaZaBrojanjeDana++;
                kopija = varijablaZaBrojanjeDana;
                for(var divovi = 1; divovi <= 12; divovi+=2) {
                    
                    if(kopija > 35) {
                        for(var jaj = divovi; jaj <= 12; jaj++) {
                            sljedece[k].children[jaj].innerHTML = "";
                            sljedece[k].children[jaj].style.border = "none";
                            sljedece[k].children[jaj].style.backgroundColor = "blue";
                        }
                        continue;
                    }
                    
                    sljedece[k].children[divovi].innerHTML = kopija-4;
                    sljedece[k].children[divovi].style.border = "1px solid white";
                    sljedece[k].children[divovi+1].style.border = "1px solid white";
                    sljedece[k].children[divovi].style.backgroundColor = "white";
                    sljedece[k].children[divovi+1].style.backgroundColor = "green";
                    kopija+=7;
                }   
            }
            for(var jhj = 0; jhj < 4; jhj++) {
                    sljedece[jhj].children[1].innerHTML = "";
                    sljedece[jhj].children[1].style.border = "none";
                    sljedece[jhj].children[1].style.backgroundColor = "blue";
                    sljedece[jhj].children[2].style.border = "none";
                    sljedece[jhj].children[2].style.backgroundColor = "blue";
                
            }
            //APRIL
        } else if(mjesec == 3) {
            datumZaZadatak.setMonth(mjesec);
            document.getElementById("imeNaKalendaru").innerHTML = "April";
            var varijablaZaBrojanjeDana = 0;
            var kopija = 0;
            for(var k = 0; k < sljedece.length; k++) {
                varijablaZaBrojanjeDana++;
                kopija = varijablaZaBrojanjeDana;
                for(var divovi = 1; divovi <= 12; divovi+=2) {
                    
                    if(kopija > 30) {
                        for(var jaj = divovi; jaj <= 12; jaj++) {
                            sljedece[k].children[jaj].innerHTML = "";
                            sljedece[k].children[jaj].style.border = "none";
                            sljedece[k].children[jaj].style.backgroundColor = "blue";
                        }
                        continue;
                    }
                    
                    sljedece[k].children[divovi].innerHTML = kopija;
                    sljedece[k].children[divovi].style.border = "1px solid white";
                    sljedece[k].children[divovi+1].style.border = "1px solid white";
                    sljedece[k].children[divovi].style.backgroundColor = "white";
                    sljedece[k].children[divovi+1].style.backgroundColor = "green";
                    kopija+=7;
                }   
            }
            
            //MAJ
        } else if(mjesec == 4) {
            datumZaZadatak.setMonth(mjesec);
            document.getElementById("imeNaKalendaru").innerHTML = "Maj";
            var varijablaZaBrojanjeDana = 0;
            var kopija = 0;
            for(var k = 0; k < sljedece.length; k++) {
                varijablaZaBrojanjeDana++;
                kopija = varijablaZaBrojanjeDana;
                for(var divovi = 1; divovi <= 12; divovi+=2) {
                    
                    if(kopija > 33) {
                        for(var jaj = divovi; jaj <= 12; jaj++) {
                            sljedece[k].children[jaj].innerHTML = "";
                            sljedece[k].children[jaj].style.border = "none";
                            sljedece[k].children[jaj].style.backgroundColor = "blue";
                        }
                        continue;
                    }
                    
                    sljedece[k].children[divovi].innerHTML = kopija-2;
                    sljedece[k].children[divovi].style.border = "1px solid white";
                    sljedece[k].children[divovi+1].style.border = "1px solid white";
                    sljedece[k].children[divovi].style.backgroundColor = "white";
                    sljedece[k].children[divovi+1].style.backgroundColor = "green";
                    kopija+=7;
                }   
            }
            
            for(var jhj = 0; jhj < 2; jhj++) {
                sljedece[jhj].children[1].innerHTML = "";
                sljedece[jhj].children[1].style.border = "none";
                sljedece[jhj].children[1].style.backgroundColor = "blue";
                sljedece[jhj].children[2].style.border = "none";
                sljedece[jhj].children[2].style.backgroundColor = "blue";
            
        }
        //JUNI
    } else if(mjesec == 5) {
        datumZaZadatak.setMonth(mjesec);
        document.getElementById("imeNaKalendaru").innerHTML = "Juni";
        var varijablaZaBrojanjeDana = 0;
        var kopija = 0;
        for(var k = 0; k < sljedece.length; k++) {
            varijablaZaBrojanjeDana++;
            kopija = varijablaZaBrojanjeDana;
            for(var divovi = 1; divovi <= 12; divovi+=2) {
                
                if(kopija > 35) {
                    for(var jaj = divovi; jaj <= 12; jaj++) {
                        sljedece[k].children[jaj].innerHTML = "";
                        sljedece[k].children[jaj].style.border = "none";
                        sljedece[k].children[jaj].style.backgroundColor = "blue";
                    }
                    continue;
                }
                
                sljedece[k].children[divovi].innerHTML = kopija-5;
                sljedece[k].children[divovi].style.border = "1px solid white";
                sljedece[k].children[divovi+1].style.border = "1px solid white";
                sljedece[k].children[divovi].style.backgroundColor = "white";
                sljedece[k].children[divovi+1].style.backgroundColor = "green";
                kopija+=7;
            }   
        }
        
        for(var jhj = 0; jhj < 5; jhj++) {
            sljedece[jhj].children[1].innerHTML = "";
            sljedece[jhj].children[1].style.border = "none";
            sljedece[jhj].children[1].style.backgroundColor = "blue";
            sljedece[jhj].children[2].style.border = "none";
            sljedece[jhj].children[2].style.backgroundColor = "blue";
        
    }
    //JULI
    } else if(mjesec == 6) {
        datumZaZadatak.setMonth(mjesec);
        document.getElementById("imeNaKalendaru").innerHTML = "Juli";
        var varijablaZaBrojanjeDana = 0;
        var kopija = 0;
        for(var k = 0; k < sljedece.length; k++) {
            varijablaZaBrojanjeDana++;
            kopija = varijablaZaBrojanjeDana;
            for(var divovi = 1; divovi <= 12; divovi+=2) {
                
                if(kopija > 31) {
                    for(var jaj = divovi; jaj <= 12; jaj++) {
                        sljedece[k].children[jaj].innerHTML = "";
                        sljedece[k].children[jaj].style.border = "none";
                        sljedece[k].children[jaj].style.backgroundColor = "blue";
                    }
                    continue;
                }
                
                sljedece[k].children[divovi].innerHTML = kopija;
                sljedece[k].children[divovi].style.border = "1px solid white";
                sljedece[k].children[divovi+1].style.border = "1px solid white";
                sljedece[k].children[divovi].style.backgroundColor = "white";
                sljedece[k].children[divovi+1].style.backgroundColor = "green";
                kopija+=7;
            }   
        }
        
        //AUGUST
    } else if(mjesec == 7) {
        datumZaZadatak.setMonth(mjesec);
        document.getElementById("imeNaKalendaru").innerHTML = "August";
        var varijablaZaBrojanjeDana = 0;
        var kopija = 0;
        for(var k = 0; k < sljedece.length; k++) {
            varijablaZaBrojanjeDana++;
            kopija = varijablaZaBrojanjeDana;
            for(var divovi = 1; divovi <= 12; divovi+=2) {
                
                if(kopija > 34) {
                    for(var jaj = divovi; jaj <= 12; jaj++) {
                        sljedece[k].children[jaj].innerHTML = "";
                        sljedece[k].children[jaj].style.border = "none";
                        sljedece[k].children[jaj].style.backgroundColor = "blue";
                    }
                    continue;
                }
                
                sljedece[k].children[divovi].innerHTML = kopija-3;
                sljedece[k].children[divovi].style.border = "1px solid white";
                sljedece[k].children[divovi+1].style.border = "1px solid white";
                sljedece[k].children[divovi].style.backgroundColor = "white";
                sljedece[k].children[divovi+1].style.backgroundColor = "green";
                kopija+=7;
            }   
        }
        for(var jhj = 0; jhj < 3; jhj++) {
            sljedece[jhj].children[1].innerHTML = "";
            sljedece[jhj].children[1].style.border = "none";
            sljedece[jhj].children[1].style.backgroundColor = "blue";
            sljedece[jhj].children[2].style.border = "none";
            sljedece[jhj].children[2].style.backgroundColor = "blue";
        
    }
        //SEPTEMBAR
    } else if(mjesec == 8) {
        datumZaZadatak.setMonth(mjesec);
        document.getElementById("imeNaKalendaru").innerHTML = "Septembar";
        var varijablaZaBrojanjeDana = 0;
        var kopija = 0;
        for(var k = 0; k < sljedece.length; k++) {
            varijablaZaBrojanjeDana++;
            kopija = varijablaZaBrojanjeDana;
            for(var divovi = 1; divovi <= 12; divovi+=2) {
                
                if(kopija > 36) {
                    for(var jaj = divovi; jaj <= 12; jaj++) {
                        sljedece[k].children[jaj].innerHTML = "";
                        sljedece[k].children[jaj].style.border = "none";
                        sljedece[k].children[jaj].style.backgroundColor = "blue";
                    }
                    continue;
                }
                
                sljedece[k].children[divovi].innerHTML = kopija-6;
                sljedece[k].children[divovi].style.border = "1px solid white";
                sljedece[k].children[divovi+1].style.border = "1px solid white";
                sljedece[k].children[divovi].style.backgroundColor = "white";
                sljedece[k].children[divovi+1].style.backgroundColor = "green";
                kopija+=7;
            }   
        }
        for(var jhj = 0; jhj < 6; jhj++) {
            sljedece[jhj].children[1].innerHTML = "";
            sljedece[jhj].children[1].style.border = "none";
            sljedece[jhj].children[1].style.backgroundColor = "blue";
            sljedece[jhj].children[2].style.border = "none";
            sljedece[jhj].children[2].style.backgroundColor = "blue";
        
    }
        //OKTOBAR
    } else if(mjesec == 9) {
        datumZaZadatak.setMonth(mjesec);
        document.getElementById("imeNaKalendaru").innerHTML = "Oktobar";
        var varijablaZaBrojanjeDana = 0;
        var kopija = 0;
        for(var k = 0; k < sljedece.length; k++) {
            varijablaZaBrojanjeDana++;
            kopija = varijablaZaBrojanjeDana;
            for(var divovi = 1; divovi <= 12; divovi+=2) {
                
                if(kopija > 32) {
                    for(var jaj = divovi; jaj <= 12; jaj++) {
                        sljedece[k].children[jaj].innerHTML = "";
                        sljedece[k].children[jaj].style.border = "none";
                        sljedece[k].children[jaj].style.backgroundColor = "blue";
                    }
                    continue;
                }
                
                sljedece[k].children[divovi].innerHTML = kopija-1;
                sljedece[k].children[divovi].style.border = "1px solid white";
                sljedece[k].children[divovi+1].style.border = "1px solid white";
                sljedece[k].children[divovi].style.backgroundColor = "white";
                sljedece[k].children[divovi+1].style.backgroundColor = "green";
                kopija+=7;
            }   
        }
        for(var jhj = 0; jhj < 1; jhj++) {
            sljedece[jhj].children[1].innerHTML = "";
            sljedece[jhj].children[1].style.border = "none";
            sljedece[jhj].children[1].style.backgroundColor = "blue";
            sljedece[jhj].children[2].style.border = "none";
            sljedece[jhj].children[2].style.backgroundColor = "blue";
        
    }
        //NOVEMBAR
    } else if(mjesec == 10) {
        datumZaZadatak.setMonth(mjesec);
        document.getElementById("imeNaKalendaru").innerHTML = "Novembar";
        var varijablaZaBrojanjeDana = 0;
        var kopija = 0;
        for(var k = 0; k < sljedece.length; k++) {
            varijablaZaBrojanjeDana++;
            kopija = varijablaZaBrojanjeDana;
            for(var divovi = 1; divovi <= 12; divovi+=2) {
                
                if(kopija > 34) {
                    for(var jaj = divovi; jaj <= 12; jaj++) {
                        sljedece[k].children[jaj].innerHTML = "";
                        sljedece[k].children[jaj].style.border = "none";
                        sljedece[k].children[jaj].style.backgroundColor = "blue";
                    }
                    continue;
                }
                
                sljedece[k].children[divovi].innerHTML = kopija-4;
                sljedece[k].children[divovi].style.border = "1px solid white";
                sljedece[k].children[divovi+1].style.border = "1px solid white";
                sljedece[k].children[divovi].style.backgroundColor = "white";
                sljedece[k].children[divovi+1].style.backgroundColor = "green";
                kopija+=7;
            }   
        }
        for(var jhj = 0; jhj < 4; jhj++) {
            sljedece[jhj].children[1].innerHTML = "";
            sljedece[jhj].children[1].style.border = "none";
            sljedece[jhj].children[1].style.backgroundColor = "blue";
            sljedece[jhj].children[2].style.border = "none";
            sljedece[jhj].children[2].style.backgroundColor = "blue";
        
    }
        //DECEMBAR
    } else if(mjesec == 11) {
        datumZaZadatak.setMonth(mjesec);
        document.getElementById("imeNaKalendaru").innerHTML = "Decembar";
        var varijablaZaBrojanjeDana = 0;
        var kopija = 0;
        for(var k = 0; k < sljedece.length; k++) {
            varijablaZaBrojanjeDana++;
            kopija = varijablaZaBrojanjeDana;
            for(var divovi = 1; divovi <= 12; divovi+=2) {
                
                if(kopija > 37) {
                    for(var jaj = divovi; jaj <= 12; jaj++) {
                        sljedece[k].children[jaj].innerHTML = "";
                        sljedece[k].children[jaj].style.border = "none";
                        sljedece[k].children[jaj].style.backgroundColor = "blue";
                    }
                    continue;
                }
                
                sljedece[k].children[divovi].innerHTML = kopija-6;
                sljedece[k].children[divovi].style.border = "1px solid white";
                sljedece[k].children[divovi+1].style.border = "1px solid white";
                sljedece[k].children[divovi].style.backgroundColor = "white";
                sljedece[k].children[divovi+1].style.backgroundColor = "green";
                kopija+=7;
            }   
        }
        for(var jhj = 0; jhj < 6; jhj++) {
            sljedece[jhj].children[1].innerHTML = "";
            sljedece[jhj].children[1].style.border = "none";
            sljedece[jhj].children[1].style.backgroundColor = "blue";
            sljedece[jhj].children[2].style.border = "none";
            sljedece[jhj].children[2].style.backgroundColor = "blue";
        
    }
        
    }
        
        
    }

    return{
        obojiZauzeca: obojiZauzecaImpl,
        ucitajPodatke: ucitajPodatkeImpl,
        iscrtajKalendar: iscrtajKalendarImpl
    }
}());

