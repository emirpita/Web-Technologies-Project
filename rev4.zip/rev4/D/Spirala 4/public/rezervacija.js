let Pozivi = (function() {
    function trebaUcitatiPodatkeImpl() {
        var onoStoSaljemoUKalendar;
        //console.log("Za test");
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                onoStoSaljemoUKalendar = JSON.parse(this.responseText);
                Kalendar.ucitajPodatke(onoStoSaljemoUKalendar.periodicnaZauzeca, onoStoSaljemoUKalendar.vanrednaZauzeca);
            }
        };
        xhttp.open("GET", "/zauzeca.json", true);
        xhttp.send();
    }

    function daSeRezerviseImpl(event) {
        
        var staProvjeravamo = event.target;
        if(confirm("Želite li rezervisati ovaj termin?")) { 
                    var provjera = true;
                    if(staProvjeravamo.style.backgroundColor == "red") {
                        provjera = false;
                        
                    }
                    
                    var sala;
                    var pocetak;
                    var kraj;
                    var datum;
                    var danKojiJeTrenutno;
                    pocetak = document.getElementById("pocetakpocetak").value;
                        kraj = document.getElementById("krajkraj").value;
                        sala = document.getElementById("salesale").options[document.getElementById("salesale").selectedIndex].value;
                        
                        var mjesec = document.getElementById("imeNaKalendaru").innerText;
                        
                        
                        danKojiJeTrenutno = staProvjeravamo.innerText;

                        if(danKojiJeTrenutno == "1") {
                            danKojiJeTrenutno = "01";
                        } else if(danKojiJeTrenutno == "2") {
                            danKojiJeTrenutno = "02";
                        } else if(danKojiJeTrenutno == "3") {
                            danKojiJeTrenutno = "03";
                        } else if(danKojiJeTrenutno == "4") {
                            danKojiJeTrenutno = "04";
                        } else if(danKojiJeTrenutno == "5") {
                            danKojiJeTrenutno = "05";
                        } else if(danKojiJeTrenutno == "6") {
                            danKojiJeTrenutno = "06";
                        } else if(danKojiJeTrenutno == "7") {
                            danKojiJeTrenutno = "07";
                        } else if(danKojiJeTrenutno == "8") {
                            danKojiJeTrenutno = "08";
                        } else if(danKojiJeTrenutno == "9") {
                            danKojiJeTrenutno = "09";
                        } 

                        if(mjesec == "Decembar") {
                            mjesec = "12";
                        } else if(mjesec == "Novembar") {
                            mjesec = "11";
                        } else if(mjesec == "Oktobar") {
                            mjesec = "10";
                        } else if(mjesec == "Septembar") {
                            mjesec = "9";
                        } else if(mjesec == "August") {
                            mjesec = "8";
                        } else if(mjesec == "Juli") {
                            mjesec = "7";
                        } else if(mjesec == "Juni") {
                            mjesec = "6";
                        } else if(mjesec == "Maj") {
                            mjesec = "5";
                        } else if(mjesec == "April") {
                            mjesec = "4";
                        } else if(mjesec == "Mart") {
                            mjesec = "3";
                        } else if(mjesec == "Februar") {
                            mjesec = "2";
                        } else if(mjesec == "Januar") {
                            mjesec = "1";
                        } 

                        

                        var godinaSada = new Date().getFullYear();
                        datum = danKojiJeTrenutno + '.' + mjesec + '.' + godinaSada;
                        podatci = JSON.stringify({"datum": datum, "pocetak": pocetak, "kraj": kraj, "naziv": sala, "predavac": "sdf"});
                   
                    if(provjera) {

                        var z = new XMLHttpRequest();
                        z.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {                                 
                                pozivanje();
                                Kalendar.obojiZauzeca(document.getElementsByClassName("podloga"), parseInt(mjesec)-1, document.getElementById("salesale").options[document.getElementById("salesale").selectedIndex].value, document.getElementById("pocetakpocetak").value, document.getElementById("krajkraj").value);
                            }
                        };
                        z.open("POST", "/rezervisanje", true);
                        z.setRequestHeader("Content-Type", "application/json");
                        z.send(podatci);

                        var zahtjev = new XMLHttpRequest();
                        zahtjev.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {                                 
                                pozivanje();
                                Kalendar.obojiZauzeca(document.getElementsByClassName("podloga"), parseInt(mjesec)-1, document.getElementById("salesale").options[document.getElementById("salesale").selectedIndex].value, document.getElementById("pocetakpocetak").value, document.getElementById("krajkraj").value);
                            }
                        };
                        zahtjev.open("POST", "/zauzeca.json", true);
                        zahtjev.setRequestHeader("Content-Type", "application/json");
                        zahtjev.send(podatci);
                    } else {
                        var zahtjevNovi = new XMLHttpRequest();
                        zahtjevNovi.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                                var nasRez = JSON.parse(this.responseText);
                                alert("Nije moguće rezervisati salu " + nasRez.naziv + " za navedeni datum " + nasRez.datum +  " i termin od " + nasRez.pocetak + " do " + nasRez.kraj + "!");
                            }
                        };
                        zahtjevNovi.open("POST", "/zauzeca.json", true);
                        var podatci2 = JSON.stringify({"datum": datum, "pocetak": pocetak, "kraj": kraj, "naziv": sala, "predavac": "sdfdsf"});
                        zahtjevNovi.setRequestHeader("Content-Type", "application/json");
                        zahtjevNovi.send(podatci2);
                    }
        }
    }

    return {
        trebaUcitatiPodatke: trebaUcitatiPodatkeImpl,
        daSeRezervise: daSeRezerviseImpl
    }
} ());


function ovakoSeRezervise(event) {
    Pozivi.daSeRezervise(event);
}

window.onload = function() {
    
    Kalendar.iscrtajKalendar(document.getElementsByClassName("podloga"), datumZaZadatak.getMonth());
    Pozivi.trebaUcitatiPodatke();
    
    //Dobijemo ovdje nas kalendar
    var kalendarRef = document.getElementsByClassName("podloga");
    var deca = kalendarRef[0].children;  
    var divContainer = deca[1];
    var sljedece = divContainer.children;

    //Dodajemo event listenere
    for(var ass = 0; ass < 7; ass++) {
        for(var brojbroj = 1; brojbroj <= 12; brojbroj+=2) {
            if(sljedece[ass].children[brojbroj-1].innerHTML == "") continue;
            sljedece[ass].children[brojbroj].addEventListener('click', Pozivi.opcijaRezervisanja);
        }
    }
}

function pozivanje() {
    Pozivi.trebaUcitatiPodatke();
}



