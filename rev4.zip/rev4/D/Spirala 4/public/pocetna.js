let Pozivi = (function() {
    this.sveSlike;
    this.pomocniIndeks = 0;

    function ucitajImpl() {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                var nas = JSON.parse(this.responseText);            
                document.getElementById("slika0").src = nas[0];
                document.getElementById("slika5").src = nas[1];
                document.getElementById("slika10").src = nas[2];
                sveSlike = nas;
            }
        };
        xhr.open("GET", "/Slike", true);
        xhr.send();
    }
    return {
        ucitaj: ucitajImpl,
    }
} ());

window.onload = function() {
    Pozivi.ucitaj();
}


function slikePrije() {
    var pratioc = 0;
    
    if(pomocniIndeks == 0 || pomocniIndeks == 2 || pomocniIndeks == 1) {
        document.getElementById("imeDugme11").disabled = true;
    } else {
            document.getElementById("slika"+ String(0)).src = sveSlike[pomocniIndeks-3];
            document.getElementById("slika"+ String(5)).src = sveSlike[pomocniIndeks-2];
            document.getElementById("slika"+ String(10)).src = sveSlike[pomocniIndeks-1];
        pomocniIndeks -= 3;
    }
}


function slikePoslije() {
    
    var pratioc;
    
    if(pomocniIndeks >= sveSlike.length-1) {
        document.getElementById("imeDugme22").disabled = true;
    } else {
        pratioc = 0;
        for(var i = pomocniIndeks; i < sveSlike.length; i++) {
            pomocniIndeks++;
            document.getElementById("slika"+ String(pratioc)).src = sveSlike[i];
            pratioc += 5;
            if(pratioc == 15) {
                break;
            }
        }  
    } 
}

