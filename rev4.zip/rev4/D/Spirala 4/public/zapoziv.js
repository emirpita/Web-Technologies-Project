function dugmeSljedece() {
    Kalendar.iscrtajKalendar(document.getElementsByClassName("podloga"), datumZaZadatak.getMonth()+1);
}

function akokorisnikpritisne() {
    Kalendar.obojiZauzeca(document.getElementsByClassName("podloga"), datumZaZadatak.getMonth(), document.getElementById("salesale").options[document.getElementById("salesale").selectedIndex].value, document.getElementById("pocetakpocetak").value, document.getElementById("krajkraj").value);
}

function dugmePrethodno() {
    Kalendar.iscrtajKalendar(document.getElementsByClassName("podloga"), datumZaZadatak.getMonth()-1);
}

